<?php

// Simple global dependency container
use \attitude\Elements\DependencyContainer;

// ... and able to load assets and concatenate them.
use \attitude\Mustache\AtomicLoader_AssetsConcatenator;

$concatenation_args = $loader_args;
$concatenation_args['publicStaticDir'] = ASSETS_ROOT_DIR;
$concatenation_args['publicStaticURL'] = ASSETS_URL;

define('ATOMIC_CONCAT_PREFIX', 'combined/');

$concatenator = new AtomicLoader_AssetsConcatenator(ASSETS_ROOT_DIR, $concatenation_args);
$concatenator->active = isset($_GET['combine-assets']) && $_GET['combine-assets']==='false' ? false : true;

// If minification is specified, overrides any `combine-assets`
if (isset($_GET['minify-assets'])) {
    $concatenator->minify = $_GET['minify-assets']==='false' ? false : true;
} elseif (isset($_GET['combine-assets'])) {
    $concatenator->minify = $_GET['combine-assets']==='false' ? false : true;
}
