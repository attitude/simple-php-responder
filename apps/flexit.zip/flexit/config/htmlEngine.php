<?php

// Simple global dependency container
use \attitude\Elements\DependencyContainer;

// Simple translations flat-file data writer/reader
use \attitude\FlatYAMLDB\TranslationsDB_Element;

// Custom template loaders, divided in folders...
use \attitude\Mustache\AtomicLoader_FilesystemLoader;

// Set locale dependency
DependencyContainer::set('global::language.locale', str_replace('-', '_', $language->locale));

// Translations database
DependencyContainer::set('global::translationsDBFile', APPROOT.'/data/translations.yaml');
DependencyContainer::set('global::translationsDBRoot', APPROOT.'/data');
DependencyContainer::set('global::translationsDBIndexes', array());
DependencyContainer::set('global::translationsDBNocache', true);

$translations_service = new TranslationsDB_Element(
    DependencyContainer::get('global::translationsDBFile'),
    DependencyContainer::get('global::translationsDBIndexes'),
    DependencyContainer::get('global::translationsDBRoot'),
    DependencyContainer::get('global::translationsDBNocache')
);

// Set service it to be available
DependencyContainer::set('global.i18n.service', $translations_service);

// Set the translation method
DependencyContainer::set('i18l::translate', function($one, $other='', $count=0, $offset=0) {
    return DependencyContainer::get('global.i18n.service')->translate($one, $other, $count, $offset);
});

// Set expanders
DependencyContainer::set('global::dataExpanders', array(
    'lastMonths' => function($args) {
        $months = array();
        $count  = isset($args['count']) ? (int) $args['count'] : 4;
        $locale = DependencyContainer::get('global::language.locale');

        // Set locale for time
        setlocale(LC_TIME, $locale);

        $time = time();

        $this_month = (int) date('n', $time);
        $this_year = (int) date('Y', $time);

        $time = time(0, 0, 0, $this_month, 1, $this_year);

        while (count($months) < $count) {
            $months[] = array(
                'fullName' => strftime('%B', $time),
                'shortName' => strftime('%b', $time),
                'order' => $this_month
            );

            $this_month--;
            if ($this_month===0) {
                $this_month = 12;
                $this_year--;
            }

            $time = mktime(0, 0, 0, $this_month, 1, $this_year);
        }


        return array_reverse($months);
    },
    'copyrightYear' => function ($args) {
        $Y = date('Y');

        if (isset($args['since']) && $Y > $args['since']) {
            return $Y;
        }

        return false;
    }
));

// English rules is used by default
//
// Set pluralisation logic for Slovak...
DependencyContainer::set('global::language.pluralRules.skSelect', function($n) {
    // Change 1,25 to 1.25 which is understood correctly as float
    if (is_string($n)) {
        $n = str_replace(',','.',$n);
    }

    if (intval($n) != $n) {
        return TranslationsDB_Element::FRACTION;
    }

    if ($n == 1) {
        return TranslationsDB_Element::ONE;
    }

    if ($n == ($n | 0) && $n >= 2 && $n <= 4) {
        return TranslationsDB_Element::FEW;
    }

    return TranslationsDB_Element::OTHER;
});

// ... and Czech has same rules
DependencyContainer::set('global::language.pluralRules.csSelect', DependencyContainer::get('global::language.pluralRules.skSelect'));

// If ever needed to run under subdir:
$_SERVER['REQUEST_ENDPOINT'] = url('/');

// Templating
$loader_args = array(
    'publicDir' => WWW_ROOT_DIR,
    'publicURL' => 'http'. (isset($_SERVER['SCHEME']) && $_SERVER['SCHEME']==='HTTPS' ? 's' : '').'://'.$_SERVER['HTTP_HOST'].(isset($_SERVER['REQUEST_ENDPOINT']) ? '/'.trim($_SERVER['REQUEST_ENDPOINT'], '/') : '').'/',
    'assets' => AtomicLoader_FilesystemLoader::getAssetDefaults()
);

// Cache path
DependencyContainer::set('global::mustacheCachePath', APPROOT.'/cache/mustache');
if (!file_exists(DependencyContainer::get('global::mustacheCachePath'))) {
    @mkdir(DependencyContainer::get('global::mustacheCachePath'), 0755, true);
}

DependencyContainer::set('global::mustacheViews',    new AtomicLoader_FilesystemLoader(APPROOT.'/public/templates/views', $loader_args));
DependencyContainer::set('global::mustachePartials', new AtomicLoader_FilesystemLoader(APPROOT.'/public/templates', $loader_args));

// More Mustache helpers
DependencyContainer::set('global::markdownParser', new \Parsedown());
DependencyContainer::set('global::mustacheHelpers', array(
    'markdown' => function($str) {
        return DependencyContainer::get('global::markdownParser')->parse($str);
    },
    'csslinebreaks' => function($str) {
        $lines = explode('<br>', preg_replace('/<br.*?\/?>/', '<br>', $str));

        foreach ($lines as $i => &$line) {
            $line = '<span class="csslinebreak csslinebreak--'.($i+1).'">'.$line.'</span>';
        }

        return implode('', $lines);
    },
    'headtitle' => function($arr) {
        return implode(' / ', (array) $arr);
    }
));
