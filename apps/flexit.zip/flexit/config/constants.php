<?php

define('ASSETS_URL', fullURL(url('/assets')));
define('ASSETS_ROOT_DIR', WWW_ROOT_DIR.'/assets');

if (!file_exists(ASSETS_ROOT_DIR)) {
    @mkdir(ASSETS_ROOT_DIR, 0755, true);
}
