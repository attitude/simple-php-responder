$('.linked-bullet').on('mouseenter mouseleave click', function(e) {
    e.preventDefault();

    var $this = $(this);
    var label = $this.data('linked-bullet');

    if (e.type==='mouseenter') {
        $('.linked-bullet--'+label).addClass('hover');
    } else if (e.type==='mouseleave') {
        $('.linked-bullet--'+label).removeClass('hover');
    } else if (e.type==='click') {
        if ($this.hasClass('hover')) {
            $('.linked-bullet--'+label).removeClass('hover');
        } else {
            $('.linked-bullet--'+label).addClass('hover');
        }
    }
});
