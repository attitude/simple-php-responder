var $interactivePlayground = $('.technology-playground-illustration'),
    $interactivePlaygroundButton = $interactivePlayground.children('.playground-button'),
    $interactivePlaygroundLanguage = $interactivePlayground.find('.playground-language > .label'),
    $interactivePlaygroundDatabase = $interactivePlayground.find('.playground-database > .label'),
    interactivePlaygrountState = false,
    interactivePlayground = {
        languages: ['PHP','Ruby', 'Perl', 'Pyton'],
        databases: ['MySQL', 'MongoDB', 'CouchDB', 'PostgreSQL', 'Redis', 'Memcached']
    },
    interactivePlaygrountIndexes = {
        language: 0,
        database: 0,
        languagesMax: 0,
        databasesMax: 0
    },
    interactivePlaygrountDelayer;

interactivePlaygrountIndexes.languageMax = interactivePlayground.languages.length;
interactivePlaygrountIndexes.databaseMax = interactivePlayground.databases.length;

$interactivePlaygroundButton.on('mouseenter mouseleave', function(e) {
    e.preventDefault();

    if (e.type==='mouseenter') {
        $interactivePlayground.addClass('open-stack');
        interactivePlaygrountState = true;
    } else {
        $interactivePlayground.removeClass('open-stack');
        interactivePlaygrountState = false;
    }
});

$interactivePlayground.on('click', function(e) {
    e.preventDefault();

    // console.log('click');

    interactivePlaygrountIndexes.language++;
    interactivePlaygrountIndexes.database++;

    if (interactivePlaygrountIndexes.language >= interactivePlaygrountIndexes.languageMax) {
        interactivePlaygrountIndexes.language = 0;
    }

    if (interactivePlaygrountIndexes.database >= interactivePlaygrountIndexes.databaseMax) {
        interactivePlaygrountIndexes.database = 0;
    }

    // console.log(interactivePlaygrountIndexes);

    $interactivePlaygroundLanguage.text(interactivePlayground.languages[ interactivePlaygrountIndexes.language ]);
    $interactivePlaygroundDatabase.text(interactivePlayground.databases[ interactivePlaygrountIndexes.database ]);

    if (interactivePlaygrountState === false) {
        $interactivePlayground.addClass('open-stack');
        interactivePlaygrountState = true;

        // console.log('Open... wait');

        clearTimeout(interactivePlaygrountDelayer);
        interactivePlaygrountDelayer = setTimeout(function() {
            $interactivePlayground.removeClass('open-stack');
            interactivePlaygrountState = false;

            // console.log('Closed.');
        }, 500);
    } else {
        $interactivePlayground.removeClass('open-stack');
        interactivePlaygrountState = false;
    }
});
