var $interactiveHosting = $('.multihosting-interactive'),
    miiPhase = 1;
$interactiveHosting.addClass('until-phase-1 until-phase-2 until-phase-3 until-phase-4');

$interactiveHosting.on('mouseover', function(e) {
    if (miiPhase===1) {
        $interactiveHosting.removeClass('until-phase-1');
        miiPhase++;
    }
});

$interactiveHosting.on('click', function(e) {
    e.preventDefault();
    e.stopPropagation();

    // console.log('click', miiPhase);

    if (miiPhase <= 4) {
        $interactiveHosting.removeClass('until-phase-'+miiPhase);
        miiPhase++;
    } else {
        // reset
        $interactiveHosting.addClass('until-phase-1 until-phase-2 until-phase-3 until-phase-4');
        miiPhase = 1;
    }
});
