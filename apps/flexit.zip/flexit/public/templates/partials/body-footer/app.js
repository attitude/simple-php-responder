/*jslint browser: true*/
(function (angular, console) {
    'use strict';
    var flexitApp = angular.module('flexitApp', ['angularLocalStorage', 'ui-rangeSlider'], function ($interpolateProvider) {
            $interpolateProvider.startSymbol('[[');
            $interpolateProvider.endSymbol(']]');
        }),
        // Regex to validate whole/integer number
        INTEGER_REGEXP = /^\-?\d+$/,
        // Regex to validate float number (with fraction)
        FLOAT_REGEXP = /^\-?\d+((\.|\,)\d+)?$/,
        // API End Point
        APIEndPoint = '//apps.flexit.sk/admin/ajax/ajax.api.php',// '/apps/admin/ajax/ajax.api.php',
        APIContentType = 'application/x-www-form-urlencoded';

    // Source: https://github.com/TheSharpieOne/angular-submit-validation/blob/master/form-validation.js
    flexitApp.directive('form', function () {
        return {
            require: 'form',
            restrict: 'E',
            link: function (scope, element, attributes) {
                var $element = $(element);

                $element.on('submit', function (e) {
                    $element.find('.ng-pristine').removeClass('ng-pristine').addClass('ng-dirty');

                    var form = scope[attributes.name];

                    if (typeof form === 'undefined') {
                        return true;
                    }

                    angular.forEach(form, function (formElement, fieldName) {
                        if (fieldName[0] === '$') {
                            return;
                        }

                        formElement.$pristine = false;
                        formElement.$dirty = true;
                        formElement.$touched = true;
                    }, this);

                    form.$setDirty();
                    scope.$apply();

                    scope.$broadcast('beforeformsubmit');
                });
            }
        };
    });

    flexitApp.directive('flexitUniqueEmail', ['$http', function (async) {
        return {
            require: 'ngModel',
            link: function (scope, elem, attrs, ctrl) {
                var reset = function () {
                        ctrl.$valid = true;
                    },
                    validate = function () {
                        var val = elem.val(),
                            ajaxConfiguration = {
                                method: 'POST',
                                url: APIEndPoint,
                                //url: 'https://apps.flexit.sk/admin/ajax/ajax.api.php',
                                data: {
                                    method: 'register',
                                    action: 'validateemail',
                                    email: val
                                },
                                headers: {
                                    'Content-Type': APIContentType
                                }
                            };

                        if (val.length > 0) {
                            async(ajaxConfiguration)
                                .success(function (data, status, headers, config) {
                                    ctrl.$setValidity('uniqueEmail', data.validity.available && data.validity.validChars);
                                    ctrl.$setValidity('uniqueEmailValidChars', data.validity.validChars);
                                    ctrl.$setValidity('uniqueEmailAvailable', data.validity.available);
                                }).error(function () {
                                    ctrl.$setValidity('uniqueEmailFailed', true);
                                });
                        } else {
                            ctrl.$setValidity('uniqueEmail', false);
                            ctrl.$setValidity('uniqueEmailValidChars', false);
                            ctrl.$setValidity('uniqueEmailAvailable', false);
                        }

                        return val;
                    };

                elem.on('blur', validate);
                elem.on('focus change', reset);

                scope.$on('beforeformsubmit', validate);
            }
        };
    }]);

    flexitApp.directive('flexitUniqueUser', ['$http', function (async) {
        return {
            require: 'ngModel',
            link: function (scope, elem, attrs, ctrl) {
                var reset = function () {
                        ctrl.$valid = true;
                    },
                    validate = function () {
                        var val = elem.val(),
                            ajaxConfiguration = {
                                method: 'POST',
                                url: APIEndPoint,
                                data: {
                                    method: 'register',
                                    action: 'validateusername',
                                    username: val
                                },
                                headers: {
                                    'Content-Type': APIContentType
                                }
                            };

                        console.log(ctrl.$error);

                        if (val.length > 0) {
                            async(ajaxConfiguration)
                                .success(function (data, status, headers, config) {
                                    ctrl.$setValidity('uniqueUser', data.validity.available && data.validity.validChars);
                                    ctrl.$setValidity('uniqueUserValidChars', data.validity.validChars);
                                    ctrl.$setValidity('uniqueUserAvailable', data.validity.available);
                                    ctrl.$setValidity('uniqueUserSuccess', true);
                                    console.log(ctrl.$error);
                                }).error(function (data, status, headers, config) {
                                    console.log(data, status, headers, config);
                                    ctrl.$setValidity('uniqueUserSuccess', false);
                                    console.log(ctrl.$error);
                                });
                        } else {
                            ctrl.$setValidity('uniqueUser', false);
                            ctrl.$setValidity('uniqueUserValidChars', false);
                            ctrl.$setValidity('uniqueUserAvailable', false);
                            ctrl.$setValidity('uniqueUserSuccess', false);
                            console.log(ctrl.$error);
                        }

                        console.log(ctrl.$error);

                        return val;
                    };

                elem.on('blur beforeformsubmit', validate);
                elem.on('focus change', reset);

                scope.$on('beforeformsubmit', validate);
            }
        };
    }]);

    // Souce: http://blog.yodersolutions.com/bootstrap-form-validation-done-right-in-angularjs/
    flexitApp.directive('inputValidationStatus', ['$timeout', '$log', function ($timeout, console) {
        return {
            restrict: 'A',
            require: '^form',
            transclude: true,
            template: [
                '<span class="input-validation-wrapper">',
                    '<span class="input-validation-status"',
                        ' ng-class="{',
                            "'input-validity-final': formInput.$final",
                            ',',
                            "'input-validity-error': formInput.$invalid",
                            ',',
                            "'input-validity-ok':    formInput.$valid",
                            ',',
                            "'input-validity-dirty': formInput.$dirty",
                            ',',
                            "'input-validity-touched': formInput.$touched",
                    '}" ng-bind="formInput.$pristine || formInput.$valid ? (formInput.$final && formInput.$viewValue.length > 0 ? \'&#3663\' : \'&#3664;\') : \'&times;\'"></span>',
                    '<span ng-transclude></span>',
                '</span>',
                '<span ng-if="hint && !formInput.$valid && (formInput.$viewValue.length > 0 || formInput.$dirty)" class="input-validation-hint">{{hint}}</span>'
            ].join(''),
            scope: {},
            link: function (scope, el, attrs, formCtrl) {
                // find the text box element, which has the 'name' attribute
                var inputEl   = el[0].querySelector("[name]"),
                    // convert the native text box element to an angular element
                    inputNgEl = angular.element(inputEl),
                    // get the name on the text box so we know the property to check
                    // on the form controller
                    inputName = inputNgEl.attr('name');

                if (!inputName) {
                    console.warn('Validation status diractive: Element is missing name attribute. Skipping.', el);
                    return;
                }

                el.addClass('ng-validity-final');

                scope.form = formCtrl;
                scope.formInput = formCtrl[inputName];
                scope.formInput.$final = true;

                if (typeof attrs.inputValidationStatusHint === 'string' && attrs.inputValidationStatusHint.length > 0) {
                    scope.hint = attrs.inputValidationStatusHint;
                }
                // scope.formInput.$empty = scope.formInput.$viewValue.lenth > 0;

                // only apply the has-error class after the user leaves the text box
                inputNgEl.bind('blur', function () {
                    el.addClass('ng-validity-final');
                    $timeout(function () {
                        scope.formInput.$final = true;
                    }, 0);
                });

                inputNgEl.bind('focus', function () {
                    el.removeClass('ng-validity-final');
                    $timeout(function () {
                        scope.formInput.$final = false;
                    }, 0);
                });
            }
        };
    }]);

    flexitApp.directive('ngNextInputIf', [ '$timeout', function ($timeout) {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, elm, attrs, ctrl) {
                var pattern = attrs.ngNextInputIf.length > 0 ? attrs.ngNextInputIf.split(attrs.ngNextInputIf[0]) : false;

                // If successfully split
                if (pattern && pattern.length === 3) {
                    pattern = new RegExp(pattern[1]);
                    //console.log(pattern);
                } /*else {
                    console.warn('no patern');
                }*/

                ctrl.$parsers.unshift(function (v) {
                    // No pattern: do nothing
                    if (!pattern) {
                        return v;
                    }

                    //console.log(pattern, v, v.match(pattern));

                    $timeout(function () {
                        if (v.match(pattern)) {
                            var inputs = elm.parents('form').find('input');

                            inputs.eq(inputs.index(elm) + 1).focus();
                            window.theElm = elm;

                            //console.log('matches');

                            // Remove the matched pattern in the element, since
                            // we're in withint the $timeout callback withou the $apply.
                            elm.val(v.replace(pattern, ''));
                        }
                    }, 0, false);

                    return v.trim();
                });
            }
        };
    }]);

    flexitApp.directive('integer', function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    if (INTEGER_REGEXP.test(viewValue)) {
                        // it is valid
                        ctrl.$setValidity('integer', true);
                        return parseInt(viewValue, 10);
                    }
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('integer', false);
                    return undefined;
                });
            }
        };
    });

    flexitApp.directive('boolean', function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    // console.log(viewValue);

                    if (viewValue === 'false') {
                        ctrl.$setValidity('integer', true);
                        return false;
                    }
                    if (viewValue === 'true') {
                        ctrl.$setValidity('integer', true);
                        return true;
                    }

                    ctrl.$setValidity('integer', false);
                    return undefined;
                });
            }
        };
    });

    flexitApp.directive('float', function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    if (FLOAT_REGEXP.test(viewValue)) {
                        ctrl.$setValidity('float', true);
                        return parseFloat(viewValue.replace(',', '.'));
                    }
                    ctrl.$setValidity('float', false);
                    return undefined;
                });
            }
        };
    });

    flexitApp.controller('flexitCtrl', function ($http, $scope, storage, $locale, $log, $timeout) {
        console.log('run');

        console.log($locale.id);

        // Source: https://raw.githubusercontent.com/umpirsky/country-list/master/country/cldr/en/country.json
        $scope.listOfCountries = $locale.id === 'sk-sk' ? ["Afganistan", "Alandské ostrovy", "Albánsko", "Alžírsko", "Americká Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua a Barbados", "Argentína", "Arménsko", "Aruba", "Austrália", "Azerbajdžan", "Bahamy", "Bahrajn", "Bangladéš", "Barbados", "Belgicko", "Belize", "Benin", "Bermudy", "Bielorusko", "Bolívia", "Bosna a Hercegovina", "Botswana", "Bouvetov ostrov", "Brazília", "Britské panenské ostrovy", "Britské územie v Indickom oceáne", "Brunej", "Bulharsko", "Burkina Faso", "Burundi", "Bután", "Chorvátsko", "Cookove ostrovy", "Cyprus", "Dominika", "Dominikánska republika", "Dánsko", "Džibuti", "Egypt", "Ekvádor", "Eritrea", "Estónsko", "Etiópia", "Faerské ostrovy", "Falklandské ostrovy", "Fidži", "Filipíny", "Francúzska Guayana", "Francúzska Polynézia", "Francúzske južné územia", "Francúzsko", "Fínsko", "Gabon", "Gambia", "Ghana", "Gibraltár", "Grenada", "Gruzínsko", "Grécko", "Grónsko", "Guadeloupe", "Guam", "Guatemala", "Guayana", "Guernsey", "Guinea", "Guinea-Bissau", "Haiti", "Heardove ostrovy a McDonaldove ostrovy", "Holandsko", "Holandské Antily", "Honduras", "Hong Kong S.A.R. Číny", "India", "Indonézia", "Irak", "Irán", "Island", "Izrael", "Jamajka", "Japonsko", "Jemen", "Jersey", "Jordánsko", "Južná Afrika", "Južná Georgia a Južné Sandwichove ostrovy", "Kajmanské ostrovy", "Kambodža", "Kamerun", "Kanada", "Kapverdy", "Katar", "Kazachstan", "Keňa", "Kirgizsko", "Kiribati", "Kokosové ostrovy", "Kolumbia", "Komory", "Kongo", "Konžská demokratická republika", "Kostarika", "Kuba", "Kuvajt", "Kórejská republika", "Kórejská ľudovodemokratická republika", "Laoská ľudovodemokratická republika", "Lesotho", "Libanon", "Libéria", "Lichtenštajnsko", "Litva", "Lotyšsko", "Luxembursko", "Lýbijská arabská džamahírija", "Macedónsko", "Madagaskar", "Makao S.A.R. Číny", "Malajzia", "Malawi", "Maldivy", "Mali", "Malta", "Maroko", "Marshallove ostrovy", "Martinik", "Mauritánia", "Maurícius", "Mayotte", "Maďarsko", "Menšie odľahlé ostrovy USA", "Mexiko", "Mikronézia", "Mjanmarsko", "Moldavsko", "Monako", "Mongolsko", "Montserrat", "Mozambik", "Namíbia", "Nauru", "Nemecko", "Nepál", "Neznámy alebo neplatný región", "Niger", "Nigéria", "Nikaragua", "Niue", "Norfolkov ostrov", "Nová Kaledónia", "Nový Zéland", "Nórsko", "Omán", "Ostrov Man", "Pakistan", "Palau", "Palestínske územie", "Panama", "Panenské ostrovy - USA", "Papua Nová Guinea", "Paraguaj", "Peru", "Pitcairnove ostrovy", "Pobrežie Slonoviny", "Portoriko", "Portugalsko", "Poľsko", "Rakúsko", "Reunion", "Rovníková Guinea", "Rumunsko", "Ruská federácia", "Rwanda", "Saint Kitts a Nevis", "Saint Pierre a Miquelon", "Salvador", "Samoa", "San Maríno", "Saudská Arábia", "Senegal", "Severné Mariány", "Seychelské ostrovy", "Sierra Leone", "Singapur", "Slovenská republika", "Slovinsko", "Somálsko", "Spojené arabské emiráty", "Spojené kráľovstvo", "Spojené štáty", "Srbsko", "Srbsko a Čierna Hora", "Srí Lanka", "Stredoafrická republika", "Sudán", "Surinam", "Svazijsko", "Svätá Helena", "Svätá Lucia", "Svätý Bartolomej", "Svätý Martin", "Svätý Tomáš a Princove ostrovy", "Svätý Vincent a Grenadíny", "Sýrska arabská republika", "Tadžikistan", "Tajwan", "Taliansko", "Tanzánia", "Thajsko", "Togo", "Tokelau", "Tonga", "Trinidad a Tobago", "Tunisko", "Turecko", "Turkménsko", "Turks a Caicos", "Tuvalu", "Uganda", "Ukrajina", "Uruguaj", "Uzbekistan", "Vanuatu", "Vatikán", "Venezuela", "Vianočný ostrov", "Vietnam", "Východný Timor", "Wallis a Futuna", "Zambia", "Zimbabwe", "Západná Sahara", "Írsko", "Čad", "Česká republika", "Čierna Hora", "Čile", "Čína", "Šalamúnove ostrovy", "Španielsko", "Špicbergy a Jan Mayen", "Švajčiarsko", "Švédsko"] : ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Antarctic Territory", "British Indian Ocean Territory", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Canton and Enderbury Islands", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos [Keeling] Islands", "Colombia", "Comoros", "Congo - Brazzaville", "Congo - Kinshasa", "Cook Islands", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "C\u00f4te d\u2019Ivoire", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Dronning Maud Land", "East Germany", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "French Southern and Antarctic Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard Island and McDonald Islands", "Honduras", "Hong Kong SAR China", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Johnston Island", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau SAR China", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Metropolitan France", "Mexico", "Micronesia", "Midway Islands", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar [Burma]", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "Neutral Zone", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "North Korea", "North Vietnam", "Northern Mariana Islands", "Norway", "Oman", "Pacific Islands Trust Territory", "Pakistan", "Palau", "Palestinian Territories", "Panama", "Panama Canal Zone", "Papua New Guinea", "Paraguay", "People's Democratic Republic of Yemen", "Peru", "Philippines", "Pitcairn Islands", "Poland", "Portugal", "Puerto Rico", "Qatar", "Romania", "Russia", "Rwanda", "R\u00e9union", "Saint Barth\u00e9lemy", "Saint Helena", "Saint Kitts and Nevis", "Saint Lucia", "Saint Martin", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Saudi Arabia", "Senegal", "Serbia", "Serbia and Montenegro", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "South Korea", "Spain", "Sri Lanka", "Sudan", "Suriname", "Svalbard and Jan Mayen", "Swaziland", "Sweden", "Switzerland", "Syria", "S\u00e3o Tom\u00e9 and Pr\u00edncipe", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "U.S. Minor Outlying Islands", "U.S. Miscellaneous Pacific Islands", "U.S. Virgin Islands", "Uganda", "Ukraine", "Union of Soviet Socialist Republics", "United Arab Emirates", "United Kingdom", "United States", "Unknown or Invalid Region", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Wake Island", "Wallis and Futuna", "Western Sahara", "Yemen", "Zambia", "Zimbabwe", "\u00c5land Islands"];

        var self = this,
            emptyNewUser = {
                subjectBool: false,
                subject: 'person',
                reg_username: '',
                firstname: '',
                lastname: '',
                email: '',
                street: '',
                street_no: '',
                company: '',
                ico: '',
                dic: '',
                zak_icdph: '',
                zak_city: '',
                zak_zip: ''
            },
            emptyVirtualServer = {
                type: 'virtual',
                sku: 'hosting-virtual-server',
                CPUs: 1,
                RAMs: 128,
                RAMsBurstSwap: false,
                HDDSpace: 5120,
                HDDIsSSD: false
            },
            emptyDedicatedServer = {
                type: 'dedicated',
                sku: 'hosting-dedicated-server',
                CPUs: 2,
                CPUsCores: 4,
                CPUsFrequency: 2.4, // max 3.6
                CPUsL: 3, // [2,3]
                CPUsLSize: 16, // [1,2,3,4,8,10,12,15,...,32]
                RAMs: 8, // 1 GB ... 48 GB
                HDDSpace: 4, // 1 TB ... 64 TB
                HDDIsSSD: false,
                publicIPs: 1,
                ownServer: false,
                ownServerWats: 160, // 100 - 160 - 1000 W
                fastLink: false, // 100MBit/100Mbit vs 1GBit/1GBit
                otherRequests: '',
                OS: 'debian', // ubuntu, windows, redHat
                OSOther: '', // custom other
                OSRequestInstall: true
            },
            emptyCreditsProduct = {
                type: 'credits',
                sku: 'variable-credits',
                amount: 0,
                price: 0,
                priceVat: 0,
                state: ''
            },
            creditsLevels = [{
                min: 0,
                bonus: 0,
                limit: 0.0
            }, {
                min: 50,
                bonus: 5,
                limit: 52.5
            }, {
                min: 100,
                bonus: 10,
                limit: 110.0
            }, {
                min: 200,
                bonus: 15,
                limit: 230.0
            }];

        /***********************************************************************
         LOCAL STORAGE BINDINGS
         **********************************************************************/

        storage.bind($scope, 'virtualServer', { defaultValue: emptyVirtualServer });

        storage.bind($scope, 'dedicatedServer', { defaultValue: emptyDedicatedServer });

        storage.bind($scope, 'domainValue', { defaultValue: '' });

        storage.bind($scope, 'ui', {
            defaultValue: {
                shopVisible: false,
                settingCredits: true,
                cartSignIn: false,
                userLoginFormErrorLoggedIn: false
            }
        });

        storage.bind($scope, 'cart', {
            defaultValue: {
                VAT: 1.2,

                total: 0,
                totalVAT: 0,

                credits: 0,
                creditsPrice: 0,
                creditsPriceVat: 0,

                domains: 0,
                domainsPrice: 0,
                domainsPriceVat: 0,

                domainProducts: 0,

                virtuals: 0,
                virtualsPrice: 0,
                virtualsPriceVat: 0,

                products: [
                    emptyCreditsProduct
                ]
            }
        });

        storage.bind($scope, 'user', {
            defaultValue: {
                username: '',
                profile: null
            }
        });

        storage.bind($scope, 'newUser', { defaultValue: emptyNewUser });

        // User password to autenticate
        $scope.userPassword = '';
        // TODO: show password
        $scope.userPasswordShow = false;

        $scope.appState = 'stand-by';

        /***********************************************************************
         WATCHES
         **********************************************************************/

        // New Use Registration

        $scope.$watch('newUser.street', function (v) {
            var m = typeof v === 'string' ? v.match(/(\d+)/) : false;

            //console.log(v, typeof v, m, typeof m);

            // Matches number
            if (m && typeof m === 'object') {
                $scope.newUser.street = $scope.newUser.street.replace(/(\d+)/g, '');
                $scope.newUser.street_no = typeof $scope.newUser.street_no === 'string' ? $scope.newUser.street_no + m[1] : m[1];
            }
        });

        // Virtual Servers

        $scope.$watch('virtualServer.CPUs', function (v) {
            if (v < 1) {
                $scope.virtualServer.CPUs = 1;
            }
        });
        $scope.$watch('virtualServer.RAMs', function (v) {
            if (v < 128) {
                $scope.virtualServer.RAMs = 128;
            }
        });
        $scope.$watch('virtualServer.HDDSpace', function (v) {
            if (v < 5120) {
                $scope.virtualServer.HDDSpace = 5120;
            }
        });

        $scope.$watch('dedicatedServer.CPUs', function (v) {
            if (v < 1) {
                $scope.dedicatedServer.CPUs = 1;
            }
        });
        $scope.$watch('dedicatedServer.CPUsCores', function (v) {
            if (v < 1) {
                $scope.dedicatedServer.CPUsCores = 1;
            }
        });
        $scope.$watch('dedicatedServer.RAMs', function (v) {
            if (v < 1) {
                $scope.dedicatedServer.RAMs = 1;
            }
        });
        $scope.$watch('dedicatedServer.HDDSpace', function (v) {
            if (v < 1) {
                $scope.dedicatedServer.HDDSpace = 1;
            }
        });
        $scope.$watch('dedicatedServer.publicIPs', function (v) {
            if (v < 1) {
                $scope.dedicatedServer.publicIPs = 1;
            }
        });
        $scope.$watch('dedicatedServer.ownServerWats', function (v) {
            if (v < 100) {
                $scope.dedicatedServer.ownServerWats = 100;
            }
        });

        /***********************************************************************
         UI HELPERS
         **********************************************************************/

        /**
         * UI helper: resize the input width
         */
        $scope.uiNumInputLength = function (v) {
            return v.toString().length;
        };

        /**
         * Sets the UI status of the app for 1 second
         */
        this.timeoutStatus = function (status) {
            if (!status) {
                return;
            }

            $scope.appState = status;
            setTimeout(function () {
                $scope.appState = 'stand-by';
                $scope.$apply();
            }, 1000);
        };

        /***********************************************************************
         COUNTERS
         **********************************************************************/

        /**
         * Count any products in cart
         */
        this.countProductsInCart = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart') {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count only available domains in cart
         */
        this.countDomainsInCart = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && $scope.cart.products[i].type === 'domain' && $scope.cart.products[i].status) {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count only domain transfers in cart
         */
        this.countTransfersInCart = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && $scope.cart.products[i].type === 'domain' && !$scope.cart.products[i].status) {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count any domain products (even not in cart)
         */
        this.countDomainsResults = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].type === 'domain') {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count virtual hosts in cart
         */
        this.countVirtualsInCart = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && $scope.cart.products[i].type === 'virtual') {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count dedicated in cart
         */
        this.countDedicatedInCart = function () {
            var l = $scope.cart.products.length,
                i,
                count = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && $scope.cart.products[i].type === 'dedicated') {
                    count += 1;
                }
            }

            return count;
        };

        /**
         * Count credits in cart
         */
        this.countCreditsInCart = function () {
            return $scope.cart.products[(self._getCreditsObj())].amount;
        };

        /**
         * Count credits in cart price
         */
        this.countCreditsPrice = function () {
            return $scope.cart.products[(self._getCreditsObj())].price;
        };

        /**
         * Count credits in cart price (VAT)
         */
        this.countCreditsPriceVat = function () {
            return $scope.cart.products[(self._getCreditsObj())].priceVat;
        };

        /**
         * Counts total in cart
         *
         */
        this.countTotalPrice = function () {
            var l = $scope.cart.products.length,
                i,
                total = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && typeof $scope.cart.products[i].price !== 'undefined') {
                    total += $scope.cart.products[i].price;
                }
            }

            return total;
        };

        /**
         * Counts total in cart (VAT)
         *
         */
        this.countTotalPriceVat = function () {
            var l = $scope.cart.products.length,
                i,
                total = 0;

            // Sum up
            for (i = 0; i < l; i += 1) {
                if ($scope.cart.products[i].state === 'in-cart' && typeof $scope.cart.products[i].priceVat !== 'undefined') {
                    total += $scope.cart.products[i].priceVat;
                }
            }

            return total;
        };

        /***********************************************************************
         CALCULATORS & CONVERTERS
         **********************************************************************/

        this.virtualCPUCredits = function (v) {
            return 1.05 * v;
        };

        this.virtualRAMCredits = function (v, precisely) {
            if (!precisely) {
                precisely = true;
            }
            return !precisely ? self.round(v / 1024 * 9.3125) : v / 1024 * 9.3125;
        };

        this.virtualHDDSpaceCredits = function (v, ssd, precisely) {
            var k = 0.266,
                SSDk = 4;
            if (!precisely) {
                precisely = true;
            }
            if (!ssd) {
                ssd = false;
            }

            if (v >= 120) {
                k = 0.25833333333333;
            }
            if (v >= 140) {
                k = 0.23571428571429;
            }
            if (v >= 160) {
                k = 0.21875000000000;
            }
            if (v >= 180) {
                k = 0.21111111111111;
            }
            if (v >= 200) {
                k = 0.20000000000000;
            }
            if (v >= 220) {
                k = 0.19090909090909;
            }
            if (v >= 240) {
                k = 0.18000000000000;
            }

            return !precisely ? (self.round(v / 1024 * k)) * (ssd ? SSDk : 1) : (v / 1024 * k) * (ssd ? SSDk : 1);
        };

        this.convertMBtoGB = function (v) {
            return self.round(v / 1024, 2);
        };

        /***********************************************************************
         ACTIONS
         **********************************************************************/

        this.newUser = function (form) {
            var data = {
                    method: 'register',
                    action: 'new'
                },
                formEl;

            if (!form || typeof form.$addControl === 'undefined') {
                $log.error('@dev: newUser requires to pass the current form to check for validity');

                return;
            }

            formEl = $(document.forms[form.$name]);

            $timeout(function () {
                if (!form.$valid) {
                    formEl.find('[type="submit"]').toggleClass('animated ');

                    $timeout(function () {
                        formEl.find('[type="submit"]').toggleClass('animated shake');
                    }, 1000);
                } else {
                    angular.extend(data, $scope.newUser);

                    console.log(form, data);

                    $http({
                        method: 'POST',
                        url: APIEndPoint,
                        data: data,
                        headers: {
                            'Content-Type': APIContentType
                        }
                    }).success(function (data, status, headers, config) {
                        console.log(data, status, headers, config);
                        if (data.done) {
                            // Prefill the form for the user
                            $scope.user.justRegistered = true;
                            $scope.ui.cartSignIn = "sign-in";
                            $scope.user.username = $scope.newUser.reg_username;

                            // Erase the form
                            $scope.newUser = emptyNewUser;
                        } else {
                            // TODO
                        }
                    }).error(function (data, status, headers, config) {
                        console.log(data, status, headers, config);
                    });
                }
            }, 1000);
        };

        this.routePswd = function (p) {
            $scope.userPassword = p;
        };

        this.loginUser = function(cookieerror) {
            var self = this;

            // fixes invalid_cookie
            if (typeof cookieerror !== 'boolean') {
                cookieerror = false;
            }

            $http({
                method: 'POST',
                url: APIEndPoint,
                data: {
                    method: 'user',
                    action: 'login',
                    username: $scope.user.username,
                    password: $scope.userPassword
                },
                headers: {
                    'Content-Type': APIContentType
                }
            }).success(function (data, status, headers, config) {
                if (data.message === 'already_logged' || (data.done && typeof data.cookie === 'string')) {
                    $scope.ui.cartSignIn = 'logged';
                    // Promise to have sme object
                    $scope.user.profile = {};
                    // ... fill the object
                    self.fetchUser().fetchDomains().fetchVirtuals().fetchOrders().fetchMasterServers();
                } else if (data.message === 'invalid_cookie' && !cookieerror) {
                    // Try to logout user and try to login again
                    self.logout().loginUser(true);
                } else {
                    $scope.ui.userLoginFormErrorLoggedIn = true;

                    $timeout(function() {
                        $scope.ui.userLoginFormErrorLoggedIn = false;
                    }, 1000);

                    $log.warn(data);
                }
            }).error(function (data, status, headers, config) {
                $log.error(data, status, headers, config);
            });

            return this;
        };

        this.logout = function() {
            $http({
                method: 'POST',
                url: APIEndPoint,
                data: {
                    method: 'user',
                    action: 'logout',
                    username: $scope.user.username
                },
                headers: {
                    'Content-Type': APIContentType
                }
            }).success(function (data, status, headers, config) {
                if (data.done) {
                    $scope.ui.cartSignIn = 'sign-in';
                    $scope.user.profile = null;
                }
            });

            return this;
        };

        this.fetchUser = function() {
            $http({
                method: 'POST',
                url: APIEndPoint,
                data: {
                    method: 'user',
                    action: 'details',
                    username: $scope.user.username
                },
                headers: {
                    'Content-Type': APIContentType
                }
            }).success(function (data, status, headers, config) {
                $scope.user.profile = data;
            }).error(function (data, status, headers, config) {
                $scope.user.profile = false;
            });

            return this;
        };

        this.fetchDomains = function () {
            if (typeof $scope.user.profile === 'object') {
                $http({
                    method: 'POST',
                    url: APIEndPoint,
                    data: {
                        method: 'user',
                        action: 'listdomains',
                        username: $scope.user.username
                    },
                    headers: {
                        'Content-Type': APIContentType
                    }
                }).success(function (data, status, headers, config) {
                    $scope.user.domains = data;
                });
            }

            return this;
        };

        this.fetchVirtuals = function () {
            if (typeof $scope.user.profile === 'object') {
                $http({
                    method: 'POST',
                    url: APIEndPoint,
                    data: {
                        method: 'user',
                        action: 'listvirtuals',
                        username: $scope.user.username
                    },
                    headers: {
                        'Content-Type': APIContentType
                    }
                }).success(function (data, status, headers, config) {
                    $scope.user.virtuals = data;
                });
            }

            return this;
        };

        this.fetchOrders = function () {
            if (typeof $scope.user.profile === 'object') {
                $http({
                    method: 'POST',
                    url: APIEndPoint,
                    data: {
                        method: 'user',
                        action: 'listorders',
                        username: $scope.user.username
                    },
                    headers: {
                        'Content-Type': APIContentType
                    }
                }).success(function (data, status, headers, config) {
                    $scope.user.orders = data;
                });
            }

            return this;
        };

        this.fetchMasterServers = function() {
            if (typeof $scope.user.profile === 'object') {
                $http({
                    method: 'POST',
                    url: APIEndPoint,
                    data: {
                        method: 'virtual',
                        action: 'listmasters'
                    },
                    headers: {
                        'Content-Type': APIContentType
                    }
                }).success(function (data, status, headers, config) {
                    $log.log(data);
                });
            }

            return this;
        };

        this.addVirtualToCart = function () {
            var virtual = angular.copy($scope.virtualServer);

            virtual.uuid = self.uuid();
            virtual.state = 'in-cart';
            virtual.price = self.virtualCPUCredits(virtual.CPUs, true) +
                self.virtualRAMCredits(virtual.RAMs, true) +
                self.virtualHDDSpaceCredits(virtual.HDDSpace, virtual.HDDIsSSD, true);
            virtual.priceVat = virtual.price * $scope.cart.VAT;

            $scope.cart.products.push(virtual);

            self.updateCart(0, 1);
        };

        this.addDedicatedToCart = function () {
            var dedicated = angular.copy($scope.dedicatedServer);


            dedicated.uuid = self.uuid();
            dedicated.state = 'in-cart';

            $scope.cart.products.push(dedicated);

            self.updateCart(0, 1);
        };

        this.addCredits = function (amount) {
            var index = self._getCreditsObj(),
                before = $scope.cart.products[index].amount;

            if (index < 0) {
                return;
            }

            if (typeof amount === 'number') {
                $scope.cart.products[index].amount += amount;
                $scope.cart.credits = $scope.cart.products[index].amount;
            }

            self.updateCredits(before);
        };

        this.removeCredits = function () {
            var index = self._getCreditsObj(),
                before = $scope.cart.products[index].amount;

            if (index < 0) {
                return;
            }

            $scope.cart.products[index].amount = $scope.cart.credits = 0;

            self.updateCredits(before);
        };

        this.updateCredits = function (before) {
            var index = self._getCreditsObj(),
                levels = creditsLevels,
                amount = $scope.cart.products[index].amount,
                l = levels.length,
                i = 0,
                level = -1;

            if (typeof before !== 'number') {
                before = amount;
            }

            if (index < 0) {
                return;
            }

            if (amount === '') {
                amount = $scope.cart.products[index].amount = 0;
            }
            if (amount < 0) {
                amount = $scope.cart.products[index].amount = 0;
            }

            amount = $scope.cart.products[index].amount = $scope.cart.credits = Math.floor(amount);

            // Determine the level
            for (i = 0; i < l; i += 1) {
                if (amount >= levels[i].limit) {
                    level = i;
                }
            }

            $scope.cart.products[index].price = self.round(amount / (100 + levels[level].bonus) * 100, 2);
            $scope.cart.products[index].priceVat = $scope.cart.products[index].price * $scope.cart.VAT;

            $scope.cart.products[index].state = amount > 0 ? 'in-cart' : 'empty';

            self.updateCart(before, amount);
        };

        this.updateCreditsByPrice = function () {
            var index = self._getCreditsObj(),
                levels = creditsLevels,
                before = $scope.cart.products[index].amount,
                price = $scope.cart.products[index].price,
                l = levels.length,
                i = 0,
                level = -1;

            if (index < 0) {
                return;
            }

            if (price === '') {
                price = $scope.cart.products[index].price = 0;
            }
            if (price < 0) {
                price = $scope.cart.products[index].price = 0;
            }

            price = $scope.cart.products[index].price = $scope.cart.creditsPrice = Math.floor(price);

            // Determine the level
            for (i = 0; i < l; i += 1) {
                if (price >= levels[i].min / (100 + levels[i].bonus) * 100) {
                    level = i;
                }
            }

            $scope.cart.products[index].amount = Math.floor(price / 100 * (100 + levels[level].bonus));

            self.updateCredits(before);
        };

        this.updateCart = function (before, now) {
            if (before !== now) {
                if (now !== 0) {
                    self.timeoutStatus('new-in-cart');
                } else {
                    self.timeoutStatus('cart-empty');
                    $scope.ui.shopVisible = false;
                }
            }
        };

        this.remove = function (product, action) {
            if (!action) {
                action = 'revert';
            }

            if (!(action === 'revert' || action === 'remove')) {
                return;
            }

            var index = $scope.cart.products.indexOf(product),
                before = self.countProductsInCart();

            if (action === 'revert') {
                $scope.cart.products[index].state = $scope.cart.products[index].relation;
            } else {
                $scope.cart.products.splice(index, 1);
            }

            self.updateCart(before, self.countProductsInCart());
        };

        this.add = function (product) {
            // Lookup for item
            var index = $scope.cart.products.indexOf(product);

            // Set state
            $scope.cart.products[index].state = 'in-cart';

            self.updateCart();

            // console.log($scope.cart.products);

            // console.log(index, arguments, $scope.cart.products[index].state, $scope.cart.products[index], $scope.cart.products);
        };

        /**
         * Remove unused domains marked as related
         */
        this.clean = function () {
            var h = $scope.cart.products.length,
                i;

            for (i = 0; i < h; i += 1) {
                if ($scope.cart.products[i].state !== 'in-cart' && $scope.cart.products[i].relation === 'related') {
                    $scope.cart.products.splice(i, 1);
                    // splice shortens array
                    i -= 1;
                    h -= 1;
                }
            }
        };

        this.buy = function (product) {
            self.addToCart(product, 'buy');
        };

        this.transfer = function (product) {
            self.addToCart(product, 'transfer');
        };

        this.check = function () {
            if (typeof $scope.domainValue === 'string' && $scope.domainValue.length > 0) {
                // console.log('Check for ' + $scope.domainValue);
                $scope.appState = 'waiting';

                $http({
                    method: 'POST',
                    url: APIEndPoint,
                    data: {
                        'method': 'domains',
                        'action': 'status',
                        'domain': $scope.domainValue,
                        'include-related': 'true',
                        'related-count': 5
                    },
                    headers: {
                        'Content-Type': APIContentType
                    }
                }).success(function (data, status, headers, config) {
                    // Set state for animation
                    $scope.appState = 'stand-by';

                    var domains = data.items.items,
                        l,
                        i;

                    if (!data.done) {
                        self.timeoutStatus('error');
                    } else if (typeof domains === 'object') {
                        l = domains.length;

                        if (l > 0) {
                            // Mark current query
                            data.items.domain.state = data.items.domain.relation = 'queried';
                            data.items.domain.type = 'domain';

                            // Mark related
                            for (i = 1; i < l; i += 1) {
                                domains[i].state = domains[i].relation = 'related';
                                domains[i].type = 'domain';
                            }

                            // Clean old
                            self.clean();

                            $scope.cart.products = [data.items.domain].concat(domains, $scope.cart.products);

                            // Clean the search input value
                            $scope.domainValue = '';

                            // console.log(data.items);
                        } else {
                            self.timeoutStatus('error');
                        }
                    } else {
                        self.timeoutStatus('error');
                    }

                    self.updateCart();
                })
                    .error(function (data, status, headers, config) {
                        self.timeoutStatus('error');
                        // console.log('Error', data, status, headers, config);
                    });
            } else {
                self.timeoutStatus('error');
                // console.log('Empty domain string');
            }
        };

        this.order = function() {
            var self = this;

            if (self.countProductsInCart() > 0) {

            }
            // Maybe should not perform any action at all
            /* else {
                self.timeoutStatus('error');
            }*/
        };

        /***********************************************************************
         UTILITIES
         **********************************************************************/

        /**
         * Returns current index for credits product in cart
         */
        this._getCreditsObj = function () {
            // http://stackoverflow.com/questions/10557486/in-an-array-of-objects-fastest-way-to-find-the-index-of-an-object-whose-attribu
            var index = $scope.cart.products.map(function (x) {
                return x.sku;
            }).indexOf('variable-credits');

            if (index < 0) {
                $scope.cart.products.push(emptyCreditsProduct);
                index = $scope.cart.products.map(function (x) {
                    return x.sku;
                }).indexOf('variable-credits');
            }

            if (index < 0) {
                console.error('Uncaught exception: The credits object does not exist withing cart products.');
            }

            return index;
        };

        /**
         * Rounds float number to any precision
         */
        this.round = function (n, precision) {
            if (!precision) {
                precision = 0;
            }

            if (precision < 0) {
                precision = 0;
            }

            return Math.round(Number(n) * Math.pow(10, precision)) / Math.pow(10, precision);
        };

        /**
         * Generates UUID
         * @see: http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript
         */
        this.uuid = function generateUUID() {
            var d = new Date().getTime(),
                uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = (d + Math.random() * 16) % 16 | 0;
                    d = Math.floor(d / 16);
                    return (c === 'x' ? r : (r & 0x7 | 0x8)).toString(16);
                });

            return uuid;
        };
    });
}(window.angular, window.console));
