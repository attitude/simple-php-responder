/*jslint browser: true*/
(function(w, d, c, M) {
    var $notice = d.getElementById('temporary-notice'),
        $target = d.getElementById('view-header'),
        $target2 = d.getElementById('cart-inner-container'),
        $trigger = d.getElementById('temporary-notice-trigger'),
        // Autoprefix
        transformPrefix = M.csstransforms3d ? M.prefixed('transform') : false,
        // Values
        actualTransformY = null,
        lastTransformY = null,
        // Calculate height
        noticeHeightFn = function() {
            noticeHeight = $notice.offsetHeight;
            // c.log(noticeHeight);
        },
        noticeHeight = 0;

    // Run 1st time
    noticeHeightFn();
    // Attach event on resize
    w.addEventListener('resize', noticeHeightFn, false);

    // Nothing to do...
    if (!$notice || !$target || !$trigger) {
        return;
    }
    // Listen to scroll event
    w.addEventListener('scroll', function(e) {
        actualTransformY = d.body.scrollTop <= noticeHeight ? d.body.scrollTop : noticeHeight;
        // Make sure
        if (actualTransformY < 0) {
            actualTransformY = 0;
        }

        // c.log(actualTransformY);

        if (lastTransformY !== actualTransformY) {
            lastTransformY = actualTransformY;

            if (transformPrefix) {
                $target.style[transformPrefix] = 'translate3d(0,' + -1 * actualTransformY + 'px,0)';
                $target2.style[transformPrefix] = 'translate3d(0,' + -1 * actualTransformY + 'px,0)';
            } else {
                $target.style.top = -1 * actualTransformY + 'px';
                $target2.style.top = -1 * actualTransformY + 'px';
            }
        }
    }, false);
}(window, window.document, window.console, window.Modernizr));