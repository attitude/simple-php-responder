/*! statusBar.js v0.1.0 | (c) 2014 Martin Adamko | License: MIT */
/*jslint browser: true*/
(function(window) {
    'use strict';
    var webViewHead,
        webViewLayers,
        webViewLayersLength,
        statusHeight,
        statusHeightDifference,
        debug = window.location.search.match(/[\?&]debug-standalone=true/) ? true : false,
        topOffset = function() {
            var i;

            // Fix iOS scrolling out of view when landscape
            window.document.body.scrollTop = 0;

            // Portrait mode
            if (window.innerHeight > window.innerWidth) {
                statusHeight = window.innerHeight - window.screen.availHeight;
            } else {
                statusHeight = window.innerWidth - window.screen.availHeight;
            }

            if (statusHeight <= 0) {
                statusHeight = 0;
            }

            // webViewHead.style.marginTop  = -statusHeightDifference + 'px';
            webViewHead.style.paddingTop = statusHeight + 'px';
            for (i = 0; i < webViewLayersLength; i += 1) {
                webViewLayers[i].style.paddingTop = statusHeight + 'px';
            }
        },
        init = function() {
            // Apply standalone class the HTML tag
            window.document.body.parentElement.classList.add('standalone');
            // Fix iOS scrolling out of view when landscape
            window.document.body.scrollTop = 0;

            // View header element
            webViewHead = window.document.getElementById('view');
            // View layer elements like modals etc.
            webViewLayers = window.document.getElementsByClassName('view-layer');
            // Cache length
            webViewLayersLength = webViewLayers.length;
        };

    if (debug || (typeof window.navigator.standalone === 'boolean' && window.navigator.standalone)) {
        init();

        // Calculate & apply top margin when in standalone
        window.addEventListener('mediaexperiencechanged', function(e) {
            topOffset();
        });
    }
}(window));