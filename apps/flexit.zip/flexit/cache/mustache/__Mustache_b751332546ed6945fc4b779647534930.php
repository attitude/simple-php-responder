<?php

class __Mustache_b751332546ed6945fc4b779647534930 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<aside class="technology-playground">
';
        $buffer .= $indent . '    <a href="#" class="technology-playground-illustration">
';
        $buffer .= $indent . '        <img class="tpi-base" src="/assets/images/flexit-dev-playground-base.gif" width=400 height=300 />
';
        $buffer .= $indent . '        <img class="tpi-inactive" src="/assets/images/flexit-dev-playground-inactive.gif" width=400 height=300 />
';
        $buffer .= $indent . '        <span class="playground-language"><span class="label">PHP</span></span>
';
        $buffer .= $indent . '        <span class="playground-database"><span class="label">MySQL</span></span>
';
        $buffer .= $indent . '        <span class="playground-button">
';
        $buffer .= $indent . '            <span class="sign-plus">+</span>
';
        $buffer .= $indent . '            <span class="sign-refresh">&#8634;</span>
';
        $buffer .= $indent . '        </span>
';
        $buffer .= $indent . '    </a>
';
        $buffer .= $indent . '</aside>
';
        $buffer .= $indent . '<link concatenate href="http://www.flexit.sk.dev/templates/illustrations/playground/styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www.flexit.sk.dev/templates/illustrations/playground/scripts.js" type="text/javascript"></script>
';

        return $buffer;
    }
}
