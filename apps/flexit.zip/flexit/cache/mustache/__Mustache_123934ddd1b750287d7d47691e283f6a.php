<?php

class __Mustache_123934ddd1b750287d7d47691e283f6a extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<section class="landing">
';
        $buffer .= $indent . '    <header>
';
        $buffer .= $indent . '        <h1 class="headline">';
        $value = $this->resolveValue($context->find('headline'), $context, $indent);
        $filter = $context->find('markdown');
        if (!(!is_string($filter) && is_callable($filter))) {
            throw new Mustache_Exception_UnknownFilterException('markdown');
        }
        $value = call_user_func($filter, $value);
        $filter = $context->find('stripp');
        if (!(!is_string($filter) && is_callable($filter))) {
            throw new Mustache_Exception_UnknownFilterException('stripp');
        }
        $value = call_user_func($filter, $value);
        $buffer .= $value;
        $buffer .= '</h1>
';
        $buffer .= $indent . '    </header>
';
        $buffer .= $indent . '    <ul>
';
        // 'sections' section
        $value = $context->find('sections');
        $buffer .= $this->section54593369fffe7173435d2f551a4d08ca($context, $indent, $value);
        $buffer .= $indent . '    </ul>
';
        $buffer .= $indent . '    <script concatenate type="text/javascript">
';
        $buffer .= $indent . '    $(\'.landing-section:odd\').addClass(\'is-odd\');
';
        $buffer .= $indent . '    </script>
';
        $buffer .= $indent . '</section>
';
        $buffer .= $indent . '<link concatenate href="http://www.flexit.sk.dev/templates/partials/landing/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section5c099f4741dfe94001455f08f766efeb(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' header-{{illustration | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' header-';
                $value = $this->resolveValue($context->find('illustration'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0c0f6180af98385c479d275ed616ef67(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<h3 class="subheadline">{{{subtitle | markdown | stripp }}}</h3>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<h3 class="subheadline">';
                $value = $this->resolveValue($context->find('subtitle'), $context, $indent);
                $filter = $context->find('markdown');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('markdown');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('stripp');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('stripp');
                }
                $value = call_user_func($filter, $value);
                $buffer .= $value;
                $buffer .= '</h3>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section44a85eb5372487a5e9f3c174082a61ce(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>illustrations/usagetable }}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('illustrations/usagetable')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section90c431bff795962a9f585685d42dcf5a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>illustrations/multihosting}}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('illustrations/multihosting')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDd9922e43a2d4bf967b6a01da8385275(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>illustrations/playground}}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('illustrations/playground')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCe46e9e43ffd2e4f47fec151570da208(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>components/calltoactions }}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('components/calltoactions')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF711fc16915976879711e469242d4f88(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>components/notes }}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('components/notes')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section54593369fffe7173435d2f551a4d08ca(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <li class="landing-section">
            <header class="header{{#illustration}} header-{{illustration | plaintext}}{{/illustration}}">
                <h2 class="headline">{{{title | markdown | stripp}}}</h2>
            </header>
            <article>
                {{#subtitle}}<h3 class="subheadline">{{{subtitle | markdown | stripp }}}</h3>{{/subtitle}}

                {{#usageTable}}
                {{>illustrations/usagetable }}
                {{/usageTable}}

                {{#multihosting}}
                {{>illustrations/multihosting}}
                {{/multihosting}}

                {{#technologyPlayground}}
                {{>illustrations/playground}}
                {{/technologyPlayground}}

                {{{content | markdown}}}

            </article>
            <footer>
                {{#hasCallToActions}}
                {{>components/calltoactions }}
                {{/hasCallToActions}}

                {{#hasNotes}}
                {{>components/notes }}
                {{/hasNotes}}
            </footer>
        </li>
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <li class="landing-section">
';
                $buffer .= $indent . '            <header class="header';
                // 'illustration' section
                $value = $context->find('illustration');
                $buffer .= $this->section5c099f4741dfe94001455f08f766efeb($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '                <h2 class="headline">';
                $value = $this->resolveValue($context->find('title'), $context, $indent);
                $filter = $context->find('markdown');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('markdown');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('stripp');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('stripp');
                }
                $value = call_user_func($filter, $value);
                $buffer .= $value;
                $buffer .= '</h2>
';
                $buffer .= $indent . '            </header>
';
                $buffer .= $indent . '            <article>
';
                $buffer .= $indent . '                ';
                // 'subtitle' section
                $value = $context->find('subtitle');
                $buffer .= $this->section0c0f6180af98385c479d275ed616ef67($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '
';
                // 'usageTable' section
                $value = $context->find('usageTable');
                $buffer .= $this->section44a85eb5372487a5e9f3c174082a61ce($context, $indent, $value);
                $buffer .= $indent . '
';
                // 'multihosting' section
                $value = $context->find('multihosting');
                $buffer .= $this->section90c431bff795962a9f585685d42dcf5a($context, $indent, $value);
                $buffer .= $indent . '
';
                // 'technologyPlayground' section
                $value = $context->find('technologyPlayground');
                $buffer .= $this->sectionDd9922e43a2d4bf967b6a01da8385275($context, $indent, $value);
                $buffer .= $indent . '
';
                $buffer .= $indent . '                ';
                $value = $this->resolveValue($context->find('content'), $context, $indent);
                $filter = $context->find('markdown');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('markdown');
                }
                $value = call_user_func($filter, $value);
                $buffer .= $value;
                $buffer .= '
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            </article>
';
                $buffer .= $indent . '            <footer>
';
                // 'hasCallToActions' section
                $value = $context->find('hasCallToActions');
                $buffer .= $this->sectionCe46e9e43ffd2e4f47fec151570da208($context, $indent, $value);
                $buffer .= $indent . '
';
                // 'hasNotes' section
                $value = $context->find('hasNotes');
                $buffer .= $this->sectionF711fc16915976879711e469242d4f88($context, $indent, $value);
                $buffer .= $indent . '            </footer>
';
                $buffer .= $indent . '        </li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
