<?php

class __Mustache_fbb532f0b2d06f9070cee0a2a257bec5 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<div id="view-header" class="page-header">
';
        $buffer .= $indent . '    <!--div id="temporary-notice" class="inner-container wip">
';
        $buffer .= $indent . '        <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section42a38ceb6d6817562fa8a0129839d3d4($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '        <p>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section5d81d9c5ae463578364a7abd2b87e8ba($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '    </div-->
';
        $buffer .= $indent . '    <div class="page-header-inner-container inner-container">
';
        $buffer .= $indent . '        ';
        // 'collection.hasBreadcrumbs' section
        $value = $context->findDot('collection.hasBreadcrumbs');
        $buffer .= $this->section5275ade21a90af1d7e778dfdabaa1423($context, $indent, $value);
        $buffer .= ' ';
        // 'collection.hasBreadcrumbs' inverted section
        $value = $context->findDot('collection.hasBreadcrumbs');
        if (empty($value)) {
            
            $buffer .= ' ';
            if ($partial = $this->mustache->loadPartial('components/h1')) {
                $buffer .= $partial->renderInternal($context);
            }
            $buffer .= ' ';
        }
        $buffer .= ' ';
        if ($partial = $this->mustache->loadPartial('elements/cartbutton')) {
            $buffer .= $partial->renderInternal($context);
        }
        $buffer .= '
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/body-header/01-header.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/body-header/02-fixheader.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/body-header/02-hideWIP.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function section42a38ceb6d6817562fa8a0129839d3d4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'This just is a sneak peak of our website.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'This just is a sneak peak of our website.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5d81d9c5ae463578364a7abd2b87e8ba(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'We’re working hard to get things right and we listen to your feedback at support@flexit.sk. Thank you for understanding.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'We’re working hard to get things right and we listen to your feedback at support@flexit.sk. Thank you for understanding.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD4c5ea1b435191325d068da7834346e9(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' {{>components/breadcrumbs}} ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' ';
                if ($partial = $this->mustache->loadPartial('components/breadcrumbs')) {
                    $buffer .= $partial->renderInternal($context);
                }
                $buffer .= ' ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5275ade21a90af1d7e778dfdabaa1423(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' {{#collection}} {{>components/breadcrumbs}} {{/collection}} ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' ';
                // 'collection' section
                $value = $context->find('collection');
                $buffer .= $this->sectionD4c5ea1b435191325d068da7834346e9($context, $indent, $value);
                $buffer .= ' ';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
