<?php

class __Mustache_b7459060cd9e01699de95c5c7109b2a1 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<html class="no-js">
';
        $buffer .= $indent . '    <head>
';
        if ($partial = $this->mustache->loadPartial('partials/html-head')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </head>
';
        $buffer .= $indent . '    <body class="homepage" itemscope itemtype="http://schema.org/WebPage" ng-app="flexitApp">
';
        $buffer .= $indent . '        <section id="view" ng-controller="flexitCtrl as flexit" ng-class="{\'ui-shop-visible\': ui.shopVisible}">
';
        if ($partial = $this->mustache->loadPartial('partials/body-header')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        $buffer .= $indent . '
';
        $buffer .= $indent . '            <section id="content">
';
        $buffer .= $indent . '                ';
        if ($partial = $this->mustache->loadPartial('components/hero')) {
            $buffer .= $partial->renderInternal($context);
        }
        $buffer .= '<!--{ { > components/quicklinks } } -->
';
        $buffer .= $indent . '
';
        // 'item.landingPage' section
        $value = $context->findDot('item.landingPage');
        $buffer .= $this->section307eb8baf7ea93edaad0e2c6f67af3e8($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '                <div class="ui-cover" ng-click="ui.shopVisible=false"></div>
';
        $buffer .= $indent . '            </section>
';
        $buffer .= $indent . '            <section id="cart" class="overthrow">
';
        if ($partial = $this->mustache->loadPartial('partials/cart')) {
            $buffer .= $partial->renderInternal($context, $indent . '                ');
        }
        $buffer .= $indent . '            </section>
';
        $buffer .= $indent . '        </section>
';
        if ($partial = $this->mustache->loadPartial('partials/body-footer')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </body>
';
        $buffer .= $indent . '</html>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/views/homepage/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section307eb8baf7ea93edaad0e2c6f67af3e8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>partials/landing}}
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('partials/landing')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
