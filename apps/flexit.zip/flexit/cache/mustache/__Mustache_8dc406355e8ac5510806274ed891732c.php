<?php

class __Mustache_8dc406355e8ac5510806274ed891732c extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        // 'item.hero' section
        $value = $context->findDot('item.hero');
        $buffer .= $this->sectionE7b5306ab23b6cf12426d463c9222f55($context, $indent, $value);
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/components/hero/01-hero.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section3c490cf1630104477ad3511761889904(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' hero--has-triangle';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' hero--has-triangle';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE7b5306ab23b6cf12426d463c9222f55(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
<section class="hero{{#headlineIsTriangular}} hero--has-triangle{{/headlineIsTriangular}}">
    <h3 class="headline">{{{headline | nl2br | markdown | stripp}}}</h3>
</section>
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<section class="hero';
                // 'headlineIsTriangular' section
                $value = $context->find('headlineIsTriangular');
                $buffer .= $this->section3c490cf1630104477ad3511761889904($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '    <h3 class="headline">';
                $value = $this->resolveValue($context->find('headline'), $context, $indent);
                $filter = $context->find('nl2br');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('nl2br');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('markdown');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('markdown');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('stripp');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('stripp');
                }
                $value = call_user_func($filter, $value);
                $buffer .= $value;
                $buffer .= '</h3>
';
                $buffer .= $indent . '</section>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
