<?php

class __Mustache_1dda5fb668cb8d50ec3da16fd47f9348 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<aside class="usage-table">
';
        $buffer .= $indent . '    <header>
';
        $buffer .= $indent . '        <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section56115217c740e6d68e4e8883bf0b390f($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '        <ul class="important-points">
';
        // 'importantPoints' section
        $value = $context->find('importantPoints');
        $buffer .= $this->section1366c79c1a91e025f5507915ea6e2264($context, $indent, $value);
        $buffer .= $indent . '        </ul>
';
        $buffer .= $indent . '    </header>
';
        $buffer .= $indent . '    <article>
';
        // 'importantPoints' section
        $value = $context->find('importantPoints');
        $buffer .= $this->section4a7aea86ff699da7abb1a08ee33b9bdd($context, $indent, $value);
        $buffer .= $indent . '        <img class="the-graph" src="/assets/images/usage-graph-@4x.gif" />
';
        $buffer .= $indent . '        <section class="legend">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionE5d0a6e40a929ba654ebdcc80214ea5b($context, $indent, $value);
        $buffer .= '</section>
';
        $buffer .= $indent . '        <section class="vertical-axis">
';
        $buffer .= $indent . '            <ul>
';
        // 'paymentLevels' section
        $value = $context->find('paymentLevels');
        $filter = $context->find('reverse');
        if (!(!is_string($filter) && is_callable($filter))) {
            throw new Mustache_Exception_UnknownFilterException('reverse');
        }
        $value = call_user_func($filter, $value);
        $buffer .= $this->section35a7121d37f54ad8b0ae81c7468535a5($context, $indent, $value);
        $buffer .= $indent . '            </ul>
';
        $buffer .= $indent . '        </section>
';
        $buffer .= $indent . '        <span class="max-level" style="bottom: ';
        $value = $this->resolveValue($context->find('maxLevel'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '"></span>
';
        $buffer .= $indent . '        <section class="horizontal-axis">
';
        $buffer .= $indent . '            <div class="horizontal-axis-container">
';
        $buffer .= $indent . '                <ul>
';
        // 'months' section
        $value = $context->find('months');
        $buffer .= $this->sectionC779fe0453396c87055a149c5977bc94($context, $indent, $value);
        $buffer .= $indent . '                </ul>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '        </section>
';
        $buffer .= $indent . '    </article>
';
        $buffer .= $indent . '</aside>
';
        $buffer .= $indent . '<link concatenate href="http://www.flexit.sk.dev/templates/illustrations/usagetable/styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www.flexit.sk.dev/templates/illustrations/usagetable/scripts.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function section56115217c740e6d68e4e8883bf0b390f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Usage overview';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Usage overview';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1366c79c1a91e025f5507915ea6e2264(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <li><a href="#" class="linked-bullet linked-bullet--{{label | trim | lowercase}}" data-linked-bullet="{{label | trim | lowercase}}"><span class="bullet">{{label | uppercase}}</span> <span class="label">{{{text}}}</span></a></li>
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <li><a href="#" class="linked-bullet linked-bullet--';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('trim');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('trim');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('lowercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('lowercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" data-linked-bullet="';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('trim');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('trim');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('lowercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('lowercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '"><span class="bullet">';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('uppercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('uppercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '</span> <span class="label">';
                $value = $this->resolveValue($context->find('text'), $context, $indent);
                $buffer .= $value;
                $buffer .= '</span></a></li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD963072e5e25ab5ef1fe6de475b85f53(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{"var":"position.value","one":"1 credit","other":"{} credits"}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{"var":"position.value","one":"1 credit","other":"{} credits"}';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section071243ec22f834d877eb922801cbb421(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<span class="label">{{#_n}}{"var":"position.value","one":"1 credit","other":"{} credits"}{{/_n}}</span>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<span class="label">';
                // '_n' section
                $value = $context->find('_n');
                $buffer .= $this->sectionD963072e5e25ab5ef1fe6de475b85f53($context, $indent, $value);
                $buffer .= '</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4a7aea86ff699da7abb1a08ee33b9bdd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <a href="#" class="linked-bullet linked-bullet--{{label | trim | lowercase}}" data-linked-bullet="{{label | trim | lowercase}}" style="left: {{position.left}}; bottom: {{position.bottom}}">
            <span class="bullet">{{label | uppercase}}</span>
            {{#position.value}}<span class="label">{{#_n}}{"var":"position.value","one":"1 credit","other":"{} credits"}{{/_n}}</span>{{/position.value}}
        </a>
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <a href="#" class="linked-bullet linked-bullet--';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('trim');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('trim');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('lowercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('lowercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" data-linked-bullet="';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('trim');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('trim');
                }
                $value = call_user_func($filter, $value);
                $filter = $context->find('lowercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('lowercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" style="left: ';
                $value = $this->resolveValue($context->findDot('position.left'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '; bottom: ';
                $value = $this->resolveValue($context->findDot('position.bottom'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '">
';
                $buffer .= $indent . '            <span class="bullet">';
                $value = $this->resolveValue($context->find('label'), $context, $indent);
                $filter = $context->find('uppercase');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('uppercase');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '</span>
';
                $buffer .= $indent . '            ';
                // 'position.value' section
                $value = $context->findDot('position.value');
                $buffer .= $this->section071243ec22f834d877eb922801cbb421($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5d0a6e40a929ba654ebdcc80214ea5b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Used space ~ Credits per month';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Used space ~ Credits per month';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBf21737cdd2cbdc6135e7ce1b22a7300(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{"var":"credits","one":"1 credit","other":"{} credits"}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{"var":"credits","one":"1 credit","other":"{} credits"}';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section35a7121d37f54ad8b0ae81c7468535a5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <li><span class="label">{{space}}&thinsp;GB ~ {{#_n}}{"var":"credits","one":"1 credit","other":"{} credits"}{{/_n}}</span></li>
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <li><span class="label">';
                $value = $this->resolveValue($context->find('space'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '&thinsp;GB ~ ';
                // '_n' section
                $value = $context->find('_n');
                $buffer .= $this->sectionBf21737cdd2cbdc6135e7ce1b22a7300($context, $indent, $value);
                $buffer .= '</span></li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC779fe0453396c87055a149c5977bc94(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <li><span class="label">{{ fullName }}</span></li>
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <li><span class="label">';
                $value = $this->resolveValue($context->find('fullName'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '</span></li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
