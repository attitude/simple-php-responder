<?php

class __Mustache_30109f607ba0316e9d16aa0f91e1a1f1 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<meta charset="UTF-8">
';
        $buffer .= $indent . '<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, minimal-ui">
';
        $buffer .= $indent . '<title>
';
        // 'parent.title' section
        $value = $context->findDot('parent.title');
        $buffer .= $this->section74889cfab96037dc4e295fc0f0eeac53($context, $indent, $value);
        // 'parent.title' inverted section
        $value = $context->findDot('parent.title');
        if (empty($value)) {
            
            // 'collection.title' section
            $value = $context->findDot('collection.title');
            $buffer .= $this->section66fdcabe62476df71ef08720888f8144($context, $indent, $value);
            // 'collection.title' inverted section
            $value = $context->findDot('collection.title');
            if (empty($value)) {
                
                $buffer .= $indent . '            ';
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                // 'site.subtitle' section
                $value = $context->findDot('site.subtitle');
                $buffer .= $this->section847263424d6058e6487af524c25f376a($context, $indent, $value);
                $buffer .= '
';
            }
        }
        $buffer .= $indent . '</title>
';
        $buffer .= $indent . '<meta name="description" content="';
        $value = $this->resolveValue($context->findDot('collection.description'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        // 'collection.description' inverted section
        $value = $context->findDot('collection.description');
        if (empty($value)) {
            
            $value = $this->resolveValue($context->findDot('website.title'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            $buffer .= ': ';
            $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            // 'collection.subtitle' section
            $value = $context->findDot('collection.subtitle');
            $buffer .= $this->sectionBed1124ee384da2d3c3ffff8fae4fc38($context, $indent, $value);
        }
        $buffer .= '">
';
        $buffer .= $indent . '<link href=\'//fonts.googleapis.com/css?family=Open+Sans:400,600,300,800&subset=latin,latin-ext\' rel=\'stylesheet\' type=\'text/css\'>
';
        $buffer .= $indent . '<!--concatenated-assets:text/css-->
';
        $buffer .= $indent . '<script concatenate type="text/javascript">
';
        $buffer .= $indent . 'FastClick.attach(document.body);
';
        $buffer .= $indent . '</script>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/01-normalize.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/02-styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/90-animate.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!classList.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!console.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!eventlisteners.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/01-modernizr.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/02-jquery.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/03-mediaexperience.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-fastclick.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-scrollPolyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-appLayout.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-statusBar.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/10-angular.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-cookies.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-touch.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angularLocalStorage.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function section1f13bf034325fd57bd6f98b03d88ee83(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{collection.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | ';
                $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1f20d0e324444a243d4bbb4127c0973e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{site.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | ';
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section74889cfab96037dc4e295fc0f0eeac53(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
        {{parent.title | plaintext}}
        {{#collection.title}} | {{collection.title | plaintext}}{{/collection.title}}
        {{#site.title}} | {{site.title | plaintext}}{{/site.title}}
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        ';
                $value = $this->resolveValue($context->findDot('parent.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '
';
                $buffer .= $indent . '        ';
                // 'collection.title' section
                $value = $context->findDot('collection.title');
                $buffer .= $this->section1f13bf034325fd57bd6f98b03d88ee83($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        ';
                // 'site.title' section
                $value = $context->findDot('site.title');
                $buffer .= $this->section1f20d0e324444a243d4bbb4127c0973e($context, $indent, $value);
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB4d8085c73125820ef523e905c77d70d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{data.title | plaintext}} | ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('data.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= ' | ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section66fdcabe62476df71ef08720888f8144(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
            {{#data.title}}{{data.title | plaintext}} | {{/data.title}}
            {{site.title}}
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            ';
                // 'data.title' section
                $value = $context->findDot('data.title');
                $buffer .= $this->sectionB4d8085c73125820ef523e905c77d70d($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '            ';
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section847263424d6058e6487af524c25f376a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' — {{site.subtitle | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' — ';
                $value = $this->resolveValue($context->findDot('site.subtitle'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBed1124ee384da2d3c3ffff8fae4fc38(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ', {{collection.subtitle}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ', ';
                $value = $this->resolveValue($context->findDot('collection.subtitle'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
