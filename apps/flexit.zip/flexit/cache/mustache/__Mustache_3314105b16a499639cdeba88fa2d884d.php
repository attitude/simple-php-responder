<?php

class __Mustache_3314105b16a499639cdeba88fa2d884d extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<h1>';
        // 'collection.link' inverted section
        $value = $context->findDot('collection.link');
        if (empty($value)) {
            
            $buffer .= '
';
            $buffer .= $indent . '    ';
            $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            $buffer .= '
';
        }
        // 'collection.link' section
        $value = $context->findDot('collection.link');
        $buffer .= $this->sectionE11c77bb8e855e04059039282ac2809c($context, $indent, $value);
        $buffer .= $indent . '</h1>
';

        return $buffer;
    }

    private function sectionE11c77bb8e855e04059039282ac2809c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
    {{>elements/link}}
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '
';
                if ($partial = $this->mustache->loadPartial('elements/link')) {
                    $buffer .= $partial->renderInternal($context, $indent . '    ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
