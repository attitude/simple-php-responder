<?php

class __Mustache_0e965978c5f189b4981dd49a5daf6439 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<aside class="multihosting-interactive">
';
        $buffer .= $indent . '    <a href="#" class="multihosting-interactive-illustration">
';
        $buffer .= $indent . '        <img class="mii-base"    src="/assets/images/flexit-no-package--base.gif"    width=400 height=300 />
';
        $buffer .= $indent . '        <img class="mii-button"  src="/assets/images/flexit-no-package--button.gif"  width=400 height=300 />
';
        $buffer .= $indent . '        <img class="mii-phase-1" src="/assets/images/flexit-no-package--phase-1.gif" width=400 height=300 />
';
        $buffer .= $indent . '        <img class="mii-phase-2" src="/assets/images/flexit-no-package--phase-2.gif" width=400 height=300 />
';
        $buffer .= $indent . '        <img class="mii-phase-3" src="/assets/images/flexit-no-package--phase-3.gif" width=400 height=300 />
';
        $buffer .= $indent . '        <img class="mii-phase-4" src="/assets/images/flexit-no-package--phase-4.gif" width=400 height=300 />
';
        $buffer .= $indent . '    </a>
';
        $buffer .= $indent . '</aside>
';
        $buffer .= $indent . '<link concatenate href="http://www.flexit.sk.dev/templates/illustrations/multihosting/styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www.flexit.sk.dev/templates/illustrations/multihosting/scripts.js" type="text/javascript"></script>
';

        return $buffer;
    }
}
