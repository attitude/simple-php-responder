<?php

class __Mustache_a883b3f328c99c2d9c11d8a96124b81d extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<html>
';
        $buffer .= $indent . '    <head>
';
        if ($partial = $this->mustache->loadPartial('partials/html-head')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </head>
';
        $buffer .= $indent . '    <body itemscope itemtype="http://schema.org/WebPage" ng-app="flexitApp">
';
        $buffer .= $indent . '        <section id="view" ng-controller="flexitCtrl as flexit" ng-class="{\'ui-shop-visible\': ui.shopVisible}">
';
        if ($partial = $this->mustache->loadPartial('partials/body-header')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        $buffer .= $indent . '            <section id="content">
';
        $buffer .= $indent . '                <pre>
';
        // 'item' section
        $value = $context->find('item');
        $buffer .= $this->section8a6ae4d9ec5e937a68aed464ad007166($context, $indent, $value);
        $buffer .= $indent . '                </pre>
';
        $buffer .= $indent . '                <div class="ui-cover" ng-click="ui.shopVisible=false"></div>
';
        $buffer .= $indent . '            </section>
';
        $buffer .= $indent . '            <section id="cart" class="overthrow">
';
        if ($partial = $this->mustache->loadPartial('partials/cart')) {
            $buffer .= $partial->renderInternal($context, $indent . '                ');
        }
        $buffer .= $indent . '            </section>
';
        $buffer .= $indent . '        </section>
';
        if ($partial = $this->mustache->loadPartial('partials/body-footer')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </body>
';
        $buffer .= $indent . '</html>
';

        return $buffer;
    }

    private function section8a6ae4d9ec5e937a68aed464ad007166(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                        {{. | jsonpretty}}
                    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                        ';
                $value = $this->resolveValue($context->last(), $context, $indent);
                $filter = $context->find('jsonpretty');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('jsonpretty');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
