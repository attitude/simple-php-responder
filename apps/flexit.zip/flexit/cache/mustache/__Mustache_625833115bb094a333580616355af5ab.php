<?php

class __Mustache_625833115bb094a333580616355af5ab extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<div id="cart-inner-container" class="inner-container">
';
        $buffer .= $indent . '    <section class="account-section">
';
        $buffer .= $indent . '        <div class="account-section-notification notification-success" ng-if="ui.cartSignIn===\'sign-in\' && user.justRegistered && user.justRegistered === true">
';
        $buffer .= $indent . '            <a ng-click="user.justRegistered = false" class="notification-dismiss">&times;</a>
';
        $buffer .= $indent . '            ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1fdc2d021c260dfcdc31994e6e2c80c6($context, $indent, $value);
        $buffer .= ' <a ng-click="user.justRegistered = \'help\'">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionD4c6d3c34f0bb5b9d8369f37c60c2f1d($context, $indent, $value);
        $buffer .= '</a>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="account-section-notification" ng-if="ui.cartSignIn===\'sign-in\' && user.justRegistered && user.justRegistered === \'help\'">
';
        $buffer .= $indent . '            <a ng-click="user.justRegistered = false" class="notification-dismiss">&times;</a>
';
        $buffer .= $indent . '            <a ng-click="user.justRegistered = true" class="notification-history">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section0e6f235262576857cc491c1f9b7de7c4($context, $indent, $value);
        $buffer .= '</a> ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionFeae402d134c6fa2a4a5068c181f1df1($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <header ng-if="!user.loggedIn" class="has-label-on-left">
';
        $buffer .= $indent . '            <div class="account-section-actions form-input" ng-if="!ui.cartSignIn">
';
        $buffer .= $indent . '                <a class="button account-section-register" ng-click="ui.cartSignIn = ui.cartSignIn===\'register\' ? false : \'register\'">+ ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section021b42582d1a1344b283fade1e1bf76c($context, $indent, $value);
        $buffer .= '</a>
';
        $buffer .= $indent . '                <a class="button account-section-sign-in"  ng-click="ui.cartSignIn = ui.cartSignIn===\'sign-in\'  ? false : \'sign-in\'">&rarr; ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB1efa78880892eec798bee4b99abfc11($context, $indent, $value);
        $buffer .= '</a>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div ng-if="ui.cartSignIn === \'logged\' && user.profile">
';
        $buffer .= $indent . '                Ahoj [[user.username]], ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionCf309ce2e10f947288303711d58dd6fb($context, $indent, $value);
        $buffer .= ' [[user.profile.credit]] <a class="button button-log-out" ng-click="flexit.logout()">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section9518072d71d01d6c285221db5d61ebb3($context, $indent, $value);
        $buffer .= ' &rarr;</a>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <form ng-submit="flexit.loginUser()" class="account-section-sign-in-form form-input" ng-if="ui.cartSignIn===\'sign-in\'" ng-class="{\'can-continue\': user.username.length>0 && userPassword.length>0, \'animated shake\': ui.userLoginFormErrorLoggedIn}">
';
        $buffer .= $indent . '                <input type="text" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB972934c7b1f4bb65a255bf6077458fc($context, $indent, $value);
        $buffer .= '" ng-model="user.username" />
';
        $buffer .= $indent . '                <input ng-show="!userPasswordShow" type="password" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionFb1287ce8c310f118912189a98872f79($context, $indent, $value);
        $buffer .= '" ng-model="userPassword" ng-change="flexit.routePswd(userPassword)" />
';
        $buffer .= $indent . '                <input ng-show="userPasswordShow" type="text" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section4e50d9b1632f258e8c10be3e2ed759be($context, $indent, $value);
        $buffer .= '" ng-model="userPassword" ng-change="flexit.routePswd(userPassword)" />
';
        $buffer .= $indent . '                <label class="form-label-supressed"><input type="checkbox" ng-model="userPasswordShow" /> ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionAec95c7dd6a131d97d96a243dd976f4d($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                <button type="submit" class="button account-section-sign-in-form-button">&rsaquo;</button>
';
        $buffer .= $indent . '            </form>
';
        $buffer .= $indent . '            <div class="account-section-salute form-label" ng-if="ui.cartSignIn===\'sign-in\'">
';
        $buffer .= $indent . '                <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionCad959e98fc608e6fa21674a8ddaf675($context, $indent, $value);
        $buffer .= ' <a class="account-section-link" ng-click="ui.cartSignIn=false">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionD821013b09d6fb85a3f7fb8ae9cddfe6($context, $indent, $value);
        $buffer .= '</a></h2>
';
        $buffer .= $indent . '                <p>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section8e4a6cf4127cde04bf517488d84914f4($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="account-section-salute" ng-if="ui.cartSignIn===\'register\'">
';
        $buffer .= $indent . '                <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionFa9017b3b63ed3827567ac449c7403ba($context, $indent, $value);
        $buffer .= ' <a class="account-section-link" ng-click="ui.cartSignIn=false">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionD821013b09d6fb85a3f7fb8ae9cddfe6($context, $indent, $value);
        $buffer .= '</a></h2>
';
        $buffer .= $indent . '                <p>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section3adff97d6993a30c9805970832f32db5($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="account-section-salute form-label" ng-if="!ui.cartSignIn">
';
        $buffer .= $indent . '                <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionAb6f0e0887f6043e38ed3e70fc73ecf0($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '                <p>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section223dd0d349aa6766a333121dc9c061a7($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '        </header>
';
        $buffer .= $indent . '        <article>
';
        if ($partial = $this->mustache->loadPartial('partials/userregister')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        $buffer .= $indent . '        </article>
';
        $buffer .= $indent . '    </section>
';
        $buffer .= $indent . '    <section class="shopping-cart-product-sections" ng-if="ui.cartSignIn !== \'register\'">
';
        $buffer .= $indent . '        <header>
';
        $buffer .= $indent . '            <h1 class="headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionF9bbed35959b516907f92e1c366c9077($context, $indent, $value);
        $buffer .= '</h1>
';
        $buffer .= $indent . '        </header>
';
        $buffer .= $indent . '        <ul class="shopping-cart-produts-list">
';
        $buffer .= $indent . '            <li class="shopping-cart-produts-list-item">
';
        $buffer .= $indent . '                <h2>
';
        $buffer .= $indent . '                    ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section587be9d139d0aaea0b5ee31134ea9d43($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                    <a class="button shopping-cart-linkto-button" ng-click="ui.shopVisible=false" href="';
        // 'getHrefTo' section
        $value = $context->find('getHrefTo');
        $buffer .= $this->section2f932ad559d86bda0fd93cccc6c3358e($context, $indent, $value);
        $buffer .= '">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionAe760ac65b3d1fabbf7a51b837f343f2($context, $indent, $value);
        $buffer .= ' &rarr;</a>
';
        $buffer .= $indent . '                </h2>
';
        $buffer .= $indent . '                <div ng-if="flexit.countDomainsInCart() > 0">
';
        $buffer .= $indent . '                    <h3>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionCc63e8654bbb875737cf23e8e8bd87b6($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '                    <ul>
';
        $buffer .= $indent . '                        <li ng-repeat="product in cart.products | filter: {type: \'domain\', state: \'in-cart\', status: true}">
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-price">[[product.price | currency: "EUR"]] / ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section2bc04edd73a7de63ddb3c76de827328c($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                            <a ng-click="flexit.remove(product)" class="shopping-cart-product-remove">&times;</a>
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-name">[[product.domain]]</span>
';
        $buffer .= $indent . '                        </li>
';
        $buffer .= $indent . '                    </ul>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '                <div ng-if="flexit.countTransfersInCart() > 0">
';
        $buffer .= $indent . '                    <h3>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionC919e2e92f251a2997a2d9fae970e113($context, $indent, $value);
        $buffer .= '</h3>
';
        $buffer .= $indent . '                    <ul>
';
        $buffer .= $indent . '                        <li ng-repeat="product in cart.products | filter: {type: \'domain\', state: \'in-cart\', status: false}">
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-price">[[product.price | currency: "EUR"]] / ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section2bc04edd73a7de63ddb3c76de827328c($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                            <a ng-click="flexit.remove(product)" class="shopping-cart-product-remove">&times;</a>
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-name">[[product.domain]]</span>
';
        $buffer .= $indent . '                        </li>
';
        $buffer .= $indent . '                    </ul>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </li>
';
        $buffer .= $indent . '            <li class="shopping-cart-produts-list-item">
';
        $buffer .= $indent . '                <h2>
';
        $buffer .= $indent . '                    ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionBdfb7741a433159ec3eeacabd6122928($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                    <a class="button shopping-cart-linkto-button" ng-click="ui.shopVisible=false" href="';
        // 'getHrefTo' section
        $value = $context->find('getHrefTo');
        $buffer .= $this->section1a26a123d6db149caa7eec5d4068d4af($context, $indent, $value);
        $buffer .= '">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section4a9465bcf3b7f105b72163139f30ddab($context, $indent, $value);
        $buffer .= ' &rarr;</a>
';
        $buffer .= $indent . '                </h2>
';
        $buffer .= $indent . '                <div ng-if="flexit.countVirtualsInCart() > 0">
';
        $buffer .= $indent . '                    <ul>
';
        $buffer .= $indent . '                        <li ng-repeat="product in cart.products | filter: {type: \'virtual\', state: \'in-cart\'}">
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-price">[[product.price | currency: "k"]] / ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section7f0241445da5facbe2370ade1edfa079($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                            <a ng-click="flexit.remove(product, \'remove\')" class="shopping-cart-product-remove">&times;</a>
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-name">[[product.CPUs]]&times;CPU + [[flexit.convertMBtoGB(product.RAMs)]]&thinsp;GB RAM + [[flexit.convertMBtoGB(product.HDDSpace)]]&thinsp;GB&nbsp;<span ng-if="product.HDDIsSSD">SSD&nbsp;</span>HDD</span>
';
        $buffer .= $indent . '                        </li>
';
        $buffer .= $indent . '                    </ul>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </li>
';
        $buffer .= $indent . '            <li class="shopping-cart-produts-list-item">
';
        $buffer .= $indent . '                <h2>
';
        $buffer .= $indent . '                    ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1cbca912e7256109eebff29857060bc0($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                    <a class="button shopping-cart-linkto-button" ng-click="ui.shopVisible=false" href="';
        // 'getHrefTo' section
        $value = $context->find('getHrefTo');
        $buffer .= $this->section1df0639002bda6cdeb6b4d5ce43412a9($context, $indent, $value);
        $buffer .= '">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB78945cdd4ff614ec5ce6081a8e5b29e($context, $indent, $value);
        $buffer .= ' &rarr;</a>
';
        $buffer .= $indent . '                </h2>
';
        $buffer .= $indent . '                <div ng-if="flexit.countDedicatedInCart() > 0">
';
        $buffer .= $indent . '                    <ul>
';
        $buffer .= $indent . '                        <li ng-repeat="product in cart.products | filter: {type: \'dedicated\', state: \'in-cart\'}">
';
        $buffer .= $indent . '                            <span class="shopping-cart-product-price">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section483eb4806f38610ec7ecd4ab5778d06f($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                            <a ng-click="flexit.remove(product, \'remove\')" class="shopping-cart-product-remove">&times;</a>
';
        $buffer .= $indent . '                            <span ng-if="!product.ownServer" class="shopping-cart-product-name">[[product.CPUs]]&times;CPU + [[product.RAMs]]&thinsp;GB RAM + [[product.HDDSpace]]&thinsp;TB&nbsp;<span ng-if="product.HDDIsSSD">SSD&nbsp;</span>HDD<em><span ng-pluralize count="product.CPUsCores" when="{
';
        $buffer .= $indent . '                                \'1\': \'';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionBa1edf1d1c04252cf6e7418cf464a019($context, $indent, $value);
        $buffer .= '\',
';
        $buffer .= $indent . '                                \'few\': \'';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionEb574176538d8433755d5fb0534131fe($context, $indent, $value);
        $buffer .= '\',
';
        $buffer .= $indent . '                                \'other\': \'';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section8b62a659996ac8b51ef4ea24be2eda26($context, $indent, $value);
        $buffer .= '\'
';
        $buffer .= $indent . '                            }"></span>&thinsp;@&thinsp;[[product.CPUsFrequency]]GHz&thinsp;@&thinsp;[[product.CPUsLSize]]MB L[[product.CPUsL]]&thinsp;cache + [[product.fastLink ? \'1Gbit/1Gbit\' : \'100MBit/100Mbit\']] + [[product.publicIPs]]&times;IP</em></span>
';
        $buffer .= $indent . '                            <span ng-if="product.ownServer" class="shopping-cart-product-name">[[product.ownServerWats]]&times;W + [[product.fastLink ? \'1Gbit/1Gbit\' : \'100MBit/100Mbit\']] + [[product.publicIPs]]&times;IP</span>
';
        $buffer .= $indent . '                        </li>
';
        $buffer .= $indent . '                    </ul>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </li>
';
        $buffer .= $indent . '            <li class="shopping-cart-produts-list-item">
';
        $buffer .= $indent . '                <h2>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionFf35b7c5c9c256acfefe633db71a252c($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '                <div ng-if="ui.settingCredits" class="shopping-cart-credits-input" ng-repeat="product in cart.products | filter: {type: \'credits\'}">
';
        $buffer .= $indent . '                    <a ng-click="flexit.removeCredits()" class="shopping-cart-product-remove">&times;</a>&nbsp;<input style="width: [[uiNumInputLength(product.amount) + 1]]ch" type="text" ng-model="product.amount" ng-change="flexit.updateCredits()" name="amount"  autocomplete="off" spellcheck="false" /><a class="credits-units-change" ng-click="ui.settingCredits = !ui.settingCredits">&nbsp;';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section033b4d8691831ede44fa844f46aa2ef8($context, $indent, $value);
        $buffer .= ' &#8635;</a>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '                <div ng-if="! ui.settingCredits" class="shopping-cart-credits-input" ng-repeat="product in cart.products | filter: {type: \'credits\'}">
';
        $buffer .= $indent . '                    <a ng-click="flexit.removeCredits()" class="shopping-cart-product-remove">&times;</a>&nbsp;<input style="width: [[uiNumInputLength(product.price) + 1]]ch" type="text" ng-model="product.price" ng-change="flexit.updateCreditsByPrice()" name="amount" autocomplete="off" spellcheck="false" /><a class="credits-units-change credits-units-change-eur" ng-click="ui.settingCredits = !ui.settingCredits">&nbsp;EUR &#8634;</a>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </li>
';
        $buffer .= $indent . '        </ul>
';
        $buffer .= $indent . '        <div class="finish-order-wrapper">
';
        $buffer .= $indent . '            <button ng-if="flexit.countProductsInCart() <= 0" class="button finish-order">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1653a065aca0e6b3f1b55510f7992619($context, $indent, $value);
        $buffer .= '</button>
';
        $buffer .= $indent . '            <button ng-if="flexit.countProductsInCart() > 0 && ui.cartSignIn !== \'logged\'" class="button finish-order active" ng-click="ui.cartSignIn = ui.cartSignIn===\'sign-in\'  ? false : \'sign-in\'">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionE5fc7c918d3081eac5c65328598f917f($context, $indent, $value);
        $buffer .= '</button>
';
        $buffer .= $indent . '            <a ng-if="flexit.countProductsInCart() > 0 && ui.cartSignIn !== \'logged\'" class="finish-order-final-info" ng-click="ui.cartSignIn = ui.cartSignIn===\'register\' ? false : \'register\'">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionDceda262448169781cc65a5f34497492($context, $indent, $value);
        $buffer .= '</a>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '            <button type="submit" ng-if="flexit.countProductsInCart() > 0 && ui.cartSignIn === \'logged\'" class="button finish-order active">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section710e245d87bd117caed6c3e57cf3bda6($context, $indent, $value);
        $buffer .= '</button>
';
        $buffer .= $indent . '            <p class="finish-order-total-price">Total: [[flexit.countTotalPrice() | currency: "EUR"]]</p>
';
        $buffer .= $indent . '            <p class="finish-order-total-price">Total VAT: [[flexit.countTotalPriceVat() | currency: "EUR"]]</p>
';
        $buffer .= $indent . '            <p class="finish-order-final-info">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section96b088988969307e646ff1f7b778a694($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </section>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '<link concatenate href="http://www/templates/partials/cart/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section1fdc2d021c260dfcdc31994e6e2c80c6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Thank you, your registration was successfull. Please check your email for confirmation and click the link provided to activate the account.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Thank you, your registration was successfull. Please check your email for confirmation and click the link provided to activate the account.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD4c6d3c34f0bb5b9d8369f37c60c2f1d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Did not receive the email?';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Did not receive the email?';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0e6f235262576857cc491c1f9b7de7c4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '&larr; Back';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '&larr; Back';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFeae402d134c6fa2a4a5068c181f1df1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'help_check_registration_email_again_or_call_support';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'help_check_registration_email_again_or_call_support';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section021b42582d1a1344b283fade1e1bf76c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Register';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Register';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB1efa78880892eec798bee4b99abfc11(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Sign in';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Sign in';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCf309ce2e10f947288303711d58dd6fb(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--number of -->credits:';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--number of -->credits:';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9518072d71d01d6c285221db5d61ebb3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Log out';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Log out';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB972934c7b1f4bb65a255bf6077458fc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--placeholder--> yourusername';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--placeholder--> yourusername';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFb1287ce8c310f118912189a98872f79(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'password••••';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'password••••';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4e50d9b1632f258e8c10be3e2ed759be(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'password';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'password';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionAec95c7dd6a131d97d96a243dd976f4d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Show password';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Show password';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCad959e98fc608e6fa21674a8ddaf675(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Sing in or<!-- cancel-->';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Sing in or<!-- cancel-->';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD821013b09d6fb85a3f7fb8ae9cddfe6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--Do or -->cancel';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--Do or -->cancel';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8e4a6cf4127cde04bf517488d84914f4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Enter valid user name and password';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Enter valid user name and password';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFa9017b3b63ed3827567ac449c7403ba(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Register or<!-- cancel-->';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Register or<!-- cancel-->';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section3adff97d6993a30c9805970832f32db5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'No billing info required to create a new account.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'No billing info required to create a new account.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionAb6f0e0887f6043e38ed3e70fc73ecf0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Hi there!';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Hi there!';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section223dd0d349aa6766a333121dc9c061a7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Do we know each other?';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Do we know each other?';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF9bbed35959b516907f92e1c366c9077(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Shopping cart';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Shopping cart';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section587be9d139d0aaea0b5ee31134ea9d43(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Domains';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Domains';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2f932ad559d86bda0fd93cccc6c3358e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{\'_id\':\'domains\', \'_type\': \'collection\'}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{\'_id\':\'domains\', \'_type\': \'collection\'}';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionAe760ac65b3d1fabbf7a51b837f343f2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Search domains';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Search domains';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCc63e8654bbb875737cf23e8e8bd87b6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'New Domains';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'New Domains';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2bc04edd73a7de63ddb3c76de827328c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--per--> year';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--per--> year';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC919e2e92f251a2997a2d9fae970e113(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Domain Transfers';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Domain Transfers';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBdfb7741a433159ec3eeacabd6122928(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Virtuals';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Virtuals';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1a26a123d6db149caa7eec5d4068d4af(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{\'_id\':\'virtuals\', \'_type\': \'collection\'}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{\'_id\':\'virtuals\', \'_type\': \'collection\'}';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4a9465bcf3b7f105b72163139f30ddab(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Setup virtual';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Setup virtual';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7f0241445da5facbe2370ade1edfa079(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--per--> month';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--per--> month';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1cbca912e7256109eebff29857060bc0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Dedicated';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Dedicated';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1df0639002bda6cdeb6b4d5ce43412a9(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{\'_id\':\'dedicated\', \'_type\': \'collection\'}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{\'_id\':\'dedicated\', \'_type\': \'collection\'}';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB78945cdd4ff614ec5ce6081a8e5b29e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Setup dedicated';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Setup dedicated';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section483eb4806f38610ec7ecd4ab5778d06f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'needs calculation';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'needs calculation';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBa1edf1d1c04252cf6e7418cf464a019(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '1 core';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '1 core';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEb574176538d8433755d5fb0534131fe(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{few} cores';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{few} cores';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8b62a659996ac8b51ef4ea24be2eda26(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{other} cores';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '{other} cores';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFf35b7c5c9c256acfefe633db71a252c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Credits';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Credits';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section033b4d8691831ede44fa844f46aa2ef8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--amount of--> credits';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--amount of--> credits';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1653a065aca0e6b3f1b55510f7992619(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Your shopping cart is empty';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Your shopping cart is empty';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5fc7c918d3081eac5c65328598f917f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Login and complete your order';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Login and complete your order';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDceda262448169781cc65a5f34497492(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'If you haven’t created an account yet, please register &rarr;';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'If you haven’t created an account yet, please register &rarr;';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section710e245d87bd117caed6c3e57cf3bda6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Place order';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Place order';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section96b088988969307e646ff1f7b778a694(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Depending on the amount of credits you buy and bonus credits you get as a reward the price might be actually lower for recurrent payments.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Depending on the amount of credits you buy and bonus credits you get as a reward the price might be actually lower for recurrent payments.';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
