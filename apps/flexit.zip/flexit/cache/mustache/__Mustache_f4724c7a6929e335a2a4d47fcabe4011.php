<?php

class __Mustache_f4724c7a6929e335a2a4d47fcabe4011 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<div id="view-header" class="page-header">';
        $buffer .= '
';
        $buffer .= $indent . '    <div class="page-header-inner-container inner-container">
';
        // 'hasBreadcrumbs' section
        $value = $context->find('hasBreadcrumbs');
        $buffer .= $this->section1b3b3f7ec6b9dbfe4daf3e61a7471140($context, $indent, $value);
        // 'hasBreadcrumbs' inverted section
        $value = $context->find('hasBreadcrumbs');
        if (empty($value)) {
            
            if ($partial = $this->mustache->loadPartial('components/h1')) {
                $buffer .= $partial->renderInternal($context, $indent . '            ');
            }
        }
        $buffer .= $indent . '
';
        if ($partial = $this->mustache->loadPartial('elements/cartbutton')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/body-header/01-header.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/body-header/02-fixheader.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/body-header/02-hideWIP.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function sectionEeb6a77300b867009125e6c3fa690bdc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                {{>components/breadcrumbs}}
            ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                if ($partial = $this->mustache->loadPartial('components/breadcrumbs')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1b3b3f7ec6b9dbfe4daf3e61a7471140(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
            {{#collection}}
                {{>components/breadcrumbs}}
            {{/collection}}
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                // 'collection' section
                $value = $context->find('collection');
                $buffer .= $this->sectionEeb6a77300b867009125e6c3fa690bdc($context, $indent, $value);
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
