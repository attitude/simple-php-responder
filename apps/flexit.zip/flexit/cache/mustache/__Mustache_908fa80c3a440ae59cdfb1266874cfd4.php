<?php

class __Mustache_908fa80c3a440ae59cdfb1266874cfd4 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<meta charset="UTF-8">
';
        $buffer .= $indent . '<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, minimal-ui">
';
        $buffer .= $indent . '<title>';
        // 'data.title' section
        $value = $context->findDot('data.title');
        $buffer .= $this->section124135d2ee238dea0d6ba9c87797cd1c($context, $indent, $value);
        $buffer .= '
';
        // 'parent.title' section
        $value = $context->findDot('parent.title');
        $buffer .= $this->section56a1d7c80ae7e0e3e1654c435637bb2b($context, $indent, $value);
        // 'parent.title' inverted section
        $value = $context->findDot('parent.title');
        if (empty($value)) {
            
            $buffer .= $indent . '
';
            // 'collection.title' section
            $value = $context->findDot('collection.title');
            $buffer .= $this->section2551d56ec30a47d9bf781bb65661769a($context, $indent, $value);
            $buffer .= $indent . '
';
            // 'collection.title' inverted section
            $value = $context->findDot('collection.title');
            if (empty($value)) {
                
                // 'site.subtitle' section
                $value = $context->findDot('site.subtitle');
                $buffer .= $this->sectionA8cbdb3ea3cc6c725f21392030c2c4d6($context, $indent, $value);
            }
            $buffer .= '
';
        }
        $buffer .= $indent . '</title>
';
        $buffer .= $indent . '<meta name="description" content="';
        $value = $this->resolveValue($context->findDot('collection.description'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        // 'collection.description' inverted section
        $value = $context->findDot('collection.description');
        if (empty($value)) {
            
            $value = $this->resolveValue($context->findDot('website.title'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            $buffer .= ': ';
            $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            // 'collection.subtitle' section
            $value = $context->findDot('collection.subtitle');
            $buffer .= $this->sectionBed1124ee384da2d3c3ffff8fae4fc38($context, $indent, $value);
        }
        $buffer .= '">
';
        $buffer .= $indent . '<link href=\'//fonts.googleapis.com/css?family=Open+Sans:400,600,300,800&subset=latin,latin-ext\' rel=\'stylesheet\' type=\'text/css\'>
';
        $buffer .= $indent . '<!--concatenated-assets:text/css-->
';
        $buffer .= $indent . '<script concatenate type="text/javascript">
';
        $buffer .= $indent . 'FastClick.attach(document.body);
';
        $buffer .= $indent . '</script>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/01-normalize.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/02-styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/90-animate.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!classList.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!console.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!eventlisteners.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/01-modernizr.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/02-jquery.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/03-mediaexperience.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-fastclick.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-scrollPolyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-appLayout.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-statusBar.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/10-angular.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-cookies.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-touch.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angularLocalStorage.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function section124135d2ee238dea0d6ba9c87797cd1c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{data.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('data.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1f13bf034325fd57bd6f98b03d88ee83(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{collection.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | ';
                $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1f20d0e324444a243d4bbb4127c0973e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{site.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | ';
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section56a1d7c80ae7e0e3e1654c435637bb2b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
 {{#collection.title}} | {{collection.title | plaintext}}{{/collection.title}}{{#site.title}} | {{site.title | plaintext}}{{/site.title}}
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . ' ';
                // 'collection.title' section
                $value = $context->findDot('collection.title');
                $buffer .= $this->section1f13bf034325fd57bd6f98b03d88ee83($context, $indent, $value);
                // 'site.title' section
                $value = $context->findDot('site.title');
                $buffer .= $this->section1f20d0e324444a243d4bbb4127c0973e($context, $indent, $value);
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2551d56ec30a47d9bf781bb65661769a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{#site.title}} | {{site.title | plaintext}}{{/site.title}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                // 'site.title' section
                $value = $context->findDot('site.title');
                $buffer .= $this->section1f20d0e324444a243d4bbb4127c0973e($context, $indent, $value);
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA8cbdb3ea3cc6c725f21392030c2c4d6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{site.subtitle | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . ' | ';
                $value = $this->resolveValue($context->findDot('site.subtitle'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBed1124ee384da2d3c3ffff8fae4fc38(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ', {{collection.subtitle}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ', ';
                $value = $this->resolveValue($context->findDot('collection.subtitle'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
