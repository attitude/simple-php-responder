<?php

class __Mustache_e16fff2ba43b6b72d53e0d5dd21ecb9a extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<section class="services services-footer has-navigation">
';
        $buffer .= $indent . '    <h1 class="headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section25d310c7e20ba3198d25851380f9394d($context, $indent, $value);
        $buffer .= '</h1>
';
        if ($partial = $this->mustache->loadPartial('components/navigation')) {
            $buffer .= $partial->renderInternal($context, $indent . '    ');
        }
        $buffer .= $indent . '    <ul>
';
        // 'website.items' section
        $value = $context->findDot('website.items');
        $buffer .= $this->sectionB25c51ba2a09a01e9911378a902750d7($context, $indent, $value);
        $buffer .= $indent . '    </ul>
';
        $buffer .= $indent . '</section>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/sections/services-hero/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section25d310c7e20ba3198d25851380f9394d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Services';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Services';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1f310ee837cc2bb7ef82a9ea2aa4a363(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <i class="service-illustration service-illustration--{{illustration}}"></i>
                ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <i class="service-illustration service-illustration--';
                $value = $this->resolveValue($context->find('illustration'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '"></i>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section18844ee7259000fa02efb85f9c6c060f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <a href="{{href}}" title="{{title | plaintext}}">
                {{#illustration}}
                <i class="service-illustration service-illustration--{{illustration}}"></i>
                {{/illustration}}

                <h2 class="headline">{{{navigationTitle}}}</h2>
            </a>
            ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <a href="';
                $value = $this->resolveValue($context->find('href'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" title="';
                $value = $this->resolveValue($context->find('title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '">
';
                // 'illustration' section
                $value = $context->find('illustration');
                $buffer .= $this->section1f310ee837cc2bb7ef82a9ea2aa4a363($context, $indent, $value);
                $buffer .= $indent . '
';
                $buffer .= $indent . '                <h2 class="headline">';
                $value = $this->resolveValue($context->find('navigationTitle'), $context, $indent);
                $buffer .= $value;
                $buffer .= '</h2>
';
                $buffer .= $indent . '            </a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB25c51ba2a09a01e9911378a902750d7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <li class="service">
            {{#link}}
            <a href="{{href}}" title="{{title | plaintext}}">
                {{#illustration}}
                <i class="service-illustration service-illustration--{{illustration}}"></i>
                {{/illustration}}

                <h2 class="headline">{{{navigationTitle}}}</h2>
            </a>
            {{/link}}
        </li>
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <li class="service">
';
                // 'link' section
                $value = $context->find('link');
                $buffer .= $this->section18844ee7259000fa02efb85f9c6c060f($context, $indent, $value);
                $buffer .= $indent . '        </li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
