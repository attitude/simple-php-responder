<?php

class __Mustache_24a85c39e0844fac32dfc9bd0f89c061 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<meta charset="UTF-8">
';
        $buffer .= $indent . '<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, minimal-ui">
';
        $buffer .= $indent . '<title>';
        // 'data.title' section
        $value = $context->findDot('data.title');
        $buffer .= $this->sectionB4d8085c73125820ef523e905c77d70d($context, $indent, $value);
        // 'parent' section
        $value = $context->find('parent');
        $buffer .= $this->section37e64af4079e0e818d7c37b5b612f3ae($context, $indent, $value);
        // 'parent' inverted section
        $value = $context->find('parent');
        if (empty($value)) {
            
            // 'site.title' section
            $value = $context->findDot('site.title');
            $buffer .= $this->section6e50a55c3158827a52e3bbfa7f48232b($context, $indent, $value);
            // 'site.subtitle' section
            $value = $context->findDot('site.subtitle');
            $buffer .= $this->section3df8edac48cce1c9935b1181d0f6a99f($context, $indent, $value);
        }
        $buffer .= '
';
        $buffer .= $indent . '</title>
';
        $buffer .= $indent . '<meta name="description" content="';
        $value = $this->resolveValue($context->findDot('data.description'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        // 'data.description' inverted section
        $value = $context->findDot('data.description');
        if (empty($value)) {
            
            // 'data.title' section
            $value = $context->findDot('data.title');
            $buffer .= $this->section35749de20380fb0384c6ada90166b475($context, $indent, $value);
            // 'data.title' inverted section
            $value = $context->findDot('data.title');
            if (empty($value)) {
                
                $value = $this->resolveValue($context->findDot('collection.description'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                // 'collection.description' inverted section
                $value = $context->findDot('collection.description');
                if (empty($value)) {
                    
                    $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                    $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                    $buffer .= ': ';
                    $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
                    $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                }
            }
        }
        $buffer .= '">
';
        $buffer .= $indent . '<link href=\'//fonts.googleapis.com/css?family=Open+Sans:400,600,300,800&subset=latin,latin-ext\' rel=\'stylesheet\' type=\'text/css\'>
';
        $buffer .= $indent . '<!--concatenated-assets:text/css-->
';
        $buffer .= $indent . '<script concatenate type="text/javascript">
';
        $buffer .= $indent . 'FastClick.attach(document.body);
';
        $buffer .= $indent . '</script>
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/01-normalize.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/02-styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<link concatenate href="http://www/flexit.sk/templates/partials/html-head/90-animate.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!classList.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!console.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/!!eventlisteners.polyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/01-modernizr.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/02-jquery.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/03-mediaexperience.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-fastclick.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/05-scrollPolyfill.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-appLayout.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/07-statusBar.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/10-angular.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-cookies.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/11-angular-touch.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angular-slider.min.js" type="text/javascript"></script>
';
        $buffer .= $indent . '<script concatenate src="http://www/flexit.sk/templates/partials/html-head/20-angularLocalStorage.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function sectionB4d8085c73125820ef523e905c77d70d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{data.title | plaintext}} | ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('data.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= ' | ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1f20d0e324444a243d4bbb4127c0973e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' | {{site.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | ';
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section37e64af4079e0e818d7c37b5b612f3ae(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{!
        }}{{collection.title | plaintext}}{{!
        }}{{#site.title}} | {{site.title | plaintext}}{{/site.title}}{{!
    }}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                // 'site.title' section
                $value = $context->findDot('site.title');
                $buffer .= $this->section1f20d0e324444a243d4bbb4127c0973e($context, $indent, $value);
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section6e50a55c3158827a52e3bbfa7f48232b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{site.title | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('site.title'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section3df8edac48cce1c9935b1181d0f6a99f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = ' &mdash; {{site.subtitle | plaintext}}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' &mdash; ';
                $value = $this->resolveValue($context->findDot('site.subtitle'), $context, $indent);
                $filter = $context->find('plaintext');
                if (!(!is_string($filter) && is_callable($filter))) {
                    throw new Mustache_Exception_UnknownFilterException('plaintext');
                }
                $value = call_user_func($filter, $value);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section35749de20380fb0384c6ada90166b475(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '{{!
        }}{{collection.title}}: {{data.title}}{{!
    }}';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $this->resolveValue($context->findDot('collection.title'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= ': ';
                $value = $this->resolveValue($context->findDot('data.title'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
