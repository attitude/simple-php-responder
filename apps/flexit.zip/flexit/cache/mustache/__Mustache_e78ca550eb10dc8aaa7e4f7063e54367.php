<?php

class __Mustache_e78ca550eb10dc8aaa7e4f7063e54367 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<footer>
';
        if ($partial = $this->mustache->loadPartial('sections/services-hero')) {
            $buffer .= $partial->renderInternal($context, $indent . '    ');
        }
        if ($partial = $this->mustache->loadPartial('sections/support-contacts')) {
            $buffer .= $partial->renderInternal($context, $indent . '    ');
        }
        $buffer .= $indent . '    <aside class="about-site">
';
        $buffer .= $indent . '        &copy; 2014 QUANTUMS TECHNOLOGIES s.&thinsp;r.&thinsp;o. ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section44498bb6f5a2c33f99147b6e74296cc6($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '    </aside>
';
        $buffer .= $indent . '</footer>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<div id="temporary-notice-trigger"></div>
';
        $buffer .= $indent . '<style concatenate type="text/css">
';
        $buffer .= $indent . '#temporary-notice-trigger {
';
        $buffer .= $indent . '    position: absolute;
';
        $buffer .= $indent . '    top: 50%;
';
        $buffer .= $indent . '}
';
        $buffer .= $indent . '</style>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<!--concatenated-assets:text/javascript-->
';
        $buffer .= $indent . '<script type="text/javascript" src="/assets/js/locale-';
        $value = $this->resolveValue($context->findDot('website.language.code'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '.js"></script>
';
        $buffer .= $indent . '<script>
';
        $buffer .= $indent . '    if (window.location.search.match(/[\\?&]weinre=true/)) {
';
        $buffer .= $indent . '        document.write(\'<script src="http://localhost:8080/target/target-script-min.js"><\\/script>\');
';
        $buffer .= $indent . '    }
';
        $buffer .= $indent . '    $(\'body\').mediaExperience({useBreakpoints: true, prefix: "media-experience", calculateVertical: true});
';
        $buffer .= $indent . '    $(\'#cart\').mediaExperience({prefix: "el", calculateVertical: false});
';
        $buffer .= $indent . '</script>
';
        $buffer .= $indent . '<link concatenate href="http://www/Users/martin_adamko/Sites/hosts/flexit.sk/www/apps/default/templates/partials/body-footer/styles.css" media="all" rel="stylesheet" type="text/css" />
';
        $buffer .= $indent . '<script concatenate src="http://www/Users/martin_adamko/Sites/hosts/flexit.sk/www/apps/default/templates/partials/body-footer/app.js" type="text/javascript"></script>
';

        return $buffer;
    }

    private function section44498bb6f5a2c33f99147b6e74296cc6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'All rights reserved';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'All rights reserved';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
