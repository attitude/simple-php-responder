<?php

class __Mustache_3b3ccf810079cb398893f07b4d2f2ac8 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<html>
';
        $buffer .= $indent . '    <head>
';
        if ($partial = $this->mustache->loadPartial('partials/html-head')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </head>
';
        $buffer .= $indent . '    <body itemscope itemtype="http://schema.org/WebPage" ng-app="flexitApp">
';
        $buffer .= $indent . '        <section id="view" ng-controller="flexitCtrl as flexit" ng-class="{\'ui-shop-visible\': ui.shopVisible}">
';
        if ($partial = $this->mustache->loadPartial('partials/body-header')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        $buffer .= $indent . '
';
        // 'item' section
        $value = $context->find('item');
        $buffer .= $this->section663053d495e3b235cdf73106b22ef2e5($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '            <section id="cart" class="overthrow">
';
        if ($partial = $this->mustache->loadPartial('partials/cart')) {
            $buffer .= $partial->renderInternal($context, $indent . '                ');
        }
        $buffer .= $indent . '            </section>
';
        $buffer .= $indent . '        </section>
';
        $buffer .= $indent . '
';
        if ($partial = $this->mustache->loadPartial('partials/body-footer')) {
            $buffer .= $partial->renderInternal($context, $indent . '        ');
        }
        $buffer .= $indent . '    </body>
';
        $buffer .= $indent . '</html>
';

        return $buffer;
    }

    private function section663053d495e3b235cdf73106b22ef2e5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <section id="content" class="service">
                {{>sections/services-service}}
                <div class="ui-cover" ng-click="ui.shopVisible=false"></div>
            </section>
            ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <section id="content" class="service">
';
                if ($partial = $this->mustache->loadPartial('sections/services-service')) {
                    $buffer .= $partial->renderInternal($context, $indent . '                ');
                }
                $buffer .= $indent . '                <div class="ui-cover" ng-click="ui.shopVisible=false"></div>
';
                $buffer .= $indent . '            </section>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
