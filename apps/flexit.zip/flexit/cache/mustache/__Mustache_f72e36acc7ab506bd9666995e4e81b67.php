<?php

class __Mustache_f72e36acc7ab506bd9666995e4e81b67 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<nav id="navigation" role="navigation">
';
        // 'website.navigation' section
        $value = $context->findDot('website.navigation');
        $buffer .= $this->section859ebd9b6c1fe1c20c80e254eec2f33a($context, $indent, $value);
        $buffer .= $indent . '</nav>
';
        $buffer .= $indent . '<link concatenate href="http://www/templates/components/navigation/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section0b2f448bf1b5cddc0b2e0df953588fad(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <li>{{>elements/link}}</li>
        ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <li>';
                if ($partial = $this->mustache->loadPartial('elements/link')) {
                    $buffer .= $partial->renderInternal($context);
                }
                $buffer .= '</li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDef291196770b209b5a971acaf602b1e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <ul>
        {{#items}}
        <li>{{>elements/link}}</li>
        {{/items}}
    </ul>
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <ul>
';
                // 'items' section
                $value = $context->find('items');
                $buffer .= $this->section0b2f448bf1b5cddc0b2e0df953588fad($context, $indent, $value);
                $buffer .= $indent . '    </ul>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section859ebd9b6c1fe1c20c80e254eec2f33a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
    {{#hasItems}}
    <ul>
        {{#items}}
        <li>{{>elements/link}}</li>
        {{/items}}
    </ul>
    {{/hasItems}}
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                // 'hasItems' section
                $value = $context->find('hasItems');
                $buffer .= $this->sectionDef291196770b209b5a971acaf602b1e($context, $indent, $value);
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
