<?php

class __Mustache_4b5bfb0635aca4bc85cbc8697cb86618 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<form ng-submit="flexit.newUser(newUserForm)" id="new-user-form" name="newUserForm" ng-if="ui.cartSignIn===\'register\'" novalidatee>
';
        $buffer .= $indent . '    <ul class="form-sections">
';
        $buffer .= $indent . '        <li class="form-section">
';
        $buffer .= $indent . '            <div class="form-section-header">
';
        $buffer .= $indent . '                <h4 class="form-section-headline has-label-on-left">
';
        $buffer .= $indent . '                    <label class="form-input">
';
        $buffer .= $indent . '                        <input type="checkbox" ng-model="newUser.subjectBool" ng-change="newUser.subject = newUser.subjectBool ? \'company\' : \'person\'" /> ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section7df771242760c29a0679f0b225e1309f($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                    </label>
';
        $buffer .= $indent . '                    <span class="form-label">
';
        $buffer .= $indent . '                        ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section2515e54d44878c22e8e58308fc77e700($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </h4>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <ul class="form-section-values">
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section31169f4cb4979a790bcea096906aab44($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span
';
        $buffer .= $indent . '                        class="form-input"
';
        $buffer .= $indent . '                        input-validation-status
';
        $buffer .= $indent . '                        input-validation-status-hint="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section438e24e4fa29a39323a61a447d6f3e7b($context, $indent, $value);
        $buffer .= '"
';
        $buffer .= $indent . '                    >
';
        $buffer .= $indent . '                        <input ng-required="true" ng-next-input-if="/\\s+/" ng-trim="false" flexit-unique-user ng-pattern="/^[a-zA-Z0-9_]+$/" type="text" name="reg_username" ng-model="newUser.reg_username" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section671e3224991c71e262b9a287b205ee0c($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                    <!--span ng-if="newUserForm.reg_username.$error.uniqueUserAvailable === false" class="input-validation-hint input-validity-unique-available ">User name is available.</span-->
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.reg_username.$error.uniqueUserValidChars === true" class="input-validation-hint input-validity-unique-invalid-chars">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB6c36a861f6511e24b4ded69b5032368($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.reg_username.$error.uniqueUserAvailable === true && !newUserForm.reg_username.$error.uniqueUserValidChars" class="input-validation-hint input-validity-unique-not-unique">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionEbeb0b6a962981d69ca9895237780d97($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.reg_username.$error.uniqueUserFailed === false" class="input-validation-hint input-validity-unique-failed">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section8d7daa263474d019ca6184adeea76f68($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '            </ul>
';
        $buffer .= $indent . '        </li>
';
        $buffer .= $indent . '        <li class="form-section" ng-if="newUser.subject===\'company\'">
';
        $buffer .= $indent . '            <div class="form-section-header">
';
        $buffer .= $indent . '                <h4 class="form-section-headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section16e216dda66c750c4dbf625d910e823d($context, $indent, $value);
        $buffer .= '</h4>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <ul class="form-section-values">
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionBbaa6bd8dbd39fa10eeba569c807ef3b($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input ng-required="newUser.subject===\'company\' ? true : false" type="text" name="company" ng-model="newUser.company" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section58a678fea29a5602d3f0a9b11f92d37c($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section27e39a65acd510be6bfe482e046de86a($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input ng-required="newUser.subject===\'company\' ? true : false" ng-pattern="/^[\\d\\w]+$/" type="text" name="ico" ng-model="newUser.ico" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1259e38ef89d7617f51ae4e7cd724adc($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section76f6f6628e1c04e10901fef88cb6432f($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input ng-pattern="/^[\\d]+$/" type="text" name="dic" ng-model="newUser.dic" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section50bffdf828bd2a464f7a8ed88515104f($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionD4c00170a8a9be53393e332e72191fe7($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input ng-pattern="/^[\\d\\w]+$/" type="text" name="zak_icdph" ng-model="newUser.zak_icdph" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section5c10be7e79333fdbc2e46daee2575817($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '            </ul>
';
        $buffer .= $indent . '        </li>
';
        $buffer .= $indent . '        <li class="form-section">
';
        $buffer .= $indent . '            <div class="form-section-header">
';
        $buffer .= $indent . '                <h4 class="form-section-headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section7e1c22bb4b9b693009c1144090cea093($context, $indent, $value);
        $buffer .= '</h4>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <ul class="form-section-values">
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section088c140535585791f45b1310bd27da83($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input type="text" ng-required="true" ng-next-input-if="/\\s+/" ng-trim="false" ng-pattern="/^\\w+$/" name="firstname" ng-model="newUser.firstname" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB9cd9b3eed761610990f38e661af8efe($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section078ff4c628a5832c7d399c1c0dbad837($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input type="text" ng-required="true" ng-next-input-if="/\\s+/" ng-trim="false" ng-pattern="/^\\w+$/" name="lastname" ng-model="newUser.lastname" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section00ececc79c1fad4fe072f321904f6f17($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section9168bc0e583d2226592437dea05dd9ed($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <input type="email" ng-required="true" flexit-unique-email name="email" ng-model="newUser.email" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1e728b5535b030f6e2ae47754eac0fac($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                    <!--span ng-if="newUserForm.email.$error.uniqueEmailAvailable === false" class="input-validation-hint input-validity-unique-available ">E-mail address is available.</span-->
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.email.$error.uniqueEmailValidChars === true" class="input-validation-hint input-validity-unique-invalid-chars">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section9221efbafae68b73fe2f4fccdacfb988($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.email.$error.uniqueEmailAvailable === true && !newUserForm.email.$error.uniqueEmailValidChars" class="input-validation-hint input-validity-unique-not-unique">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB435ef1b474db733785ab0d9f1089af6($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '                    <span ng-if="newUserForm.email.$error.uniqueEmailFailed === false" class="input-validation-hint input-validity-unique-failed">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section8d7daa263474d019ca6184adeea76f68($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '            </ul>
';
        $buffer .= $indent . '        </li>
';
        $buffer .= $indent . '        <li class="form-section">
';
        $buffer .= $indent . '            <div class="form-section-header">
';
        $buffer .= $indent . '                <h4 class="form-section-headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section618540ae484f1912a938da7f28cc7466($context, $indent, $value);
        $buffer .= '</h4>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <ul class="form-section-values">
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section53f5102e08e798019ac5510d9591df1c($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="input-inline-group">
';
        $buffer .= $indent . '                        <span id="new-user-form-address-street" class="form-input input-inline-group-item" input-validation-status>
';
        $buffer .= $indent . '                            <input type="text" ng-next-input-if="/\\d+/" ng-required="true" name="street" ng-model="newUser.street" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section9c689cf6a11a05644403fd8cc4ad12d1($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                        </span><!--nospace
';
        $buffer .= $indent . '                        --><span id="new-user-form-address-street-no" class="form-input input-inline-group-item" input-validation-status>
';
        $buffer .= $indent . '                            <input type="text" ng-required="true" name="street_no" ng-model="newUser.street_no" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section6324e1945458733beb51476bf7b15e88($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                        </span>
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionB80241b86a8ac26c3fc95229f1f05754($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="input-inline-group">
';
        $buffer .= $indent . '                        <span id="new-user-form-address-city" class="form-input input-inline-group-item" input-validation-status>
';
        $buffer .= $indent . '                            <input type="text" ng-required="true" name="zak_city" ng-model="newUser.zak_city" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section235133ceab8cca9e745602b30de780b6($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                        </span><!--nospace
';
        $buffer .= $indent . '                        --><span id="new-user-form-address-zip" class="form-input input-inline-group-item" input-validation-status>
';
        $buffer .= $indent . '                            <input type="text" ng-required="true" name="zak_zip" ng-model="newUser.zak_zip" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section356635d831930af31155ac35a262b6c3($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                        </span>
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '                <li class="form-value">
';
        $buffer .= $indent . '                    <label class="form-label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section46a88b3cb0fa88bb97fd54c634a3fe45($context, $indent, $value);
        $buffer .= '</label>
';
        $buffer .= $indent . '                    <span class="form-input" input-validation-status>
';
        $buffer .= $indent . '                        <datalist id="new-user-countries">
';
        $buffer .= $indent . '                            <select name="country" ng-model="newUser.country">
';
        $buffer .= $indent . '                                <option ng-repeat="(key, value) in listOfCountries" value="[[value]]" ng-selected="value==newUser.country">[[value]]</option>
';
        $buffer .= $indent . '                            </select>
';
        $buffer .= $indent . '                            <p>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section129b73b9aeb65e341be7e00ebefae466($context, $indent, $value);
        $buffer .= '</p>
';
        $buffer .= $indent . '                        </datalist>
';
        $buffer .= $indent . '                        <input id="new-user-contry" list="new-user-countries" type="text" ng-required="true" name="country" ng-model="newUser.country" placeholder="';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->sectionDfe9631083bdead246adfce8ba1126d1($context, $indent, $value);
        $buffer .= '" />
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </li>
';
        $buffer .= $indent . '            </ul>
';
        $buffer .= $indent . '        </li>
';
        $buffer .= $indent . '        <li id="new-user-form-actions" class="form-section form-section-actions">
';
        $buffer .= $indent . '            <button class="button button-submit" type="submit">
';
        $buffer .= $indent . '                <span ng-hide="!newUserForm.$invalid">
';
        $buffer .= $indent . '                    ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section1a2e27af446230a7f1d40012756a32c0($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                </span>
';
        $buffer .= $indent . '                <span ng-show="!newUserForm.$invalid">
';
        $buffer .= $indent . '                    ';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section96b954b4a152d0cff3aa1178ea13712f($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '                </span>
';
        $buffer .= $indent . '            </button>
';
        $buffer .= $indent . '        </li>
';
        $buffer .= $indent . '    </ul>
';
        $buffer .= $indent . '</form>
';

        return $buffer;
    }

    private function section7df771242760c29a0679f0b225e1309f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Register as company';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Register as company';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2515e54d44878c22e8e58308fc77e700(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Account';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Account';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section31169f4cb4979a790bcea096906aab44(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'New user';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'New user';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section438e24e4fa29a39323a61a447d6f3e7b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Use any of these charakters: a-z, A-Z, 0-9, . (dot) or _ (underscore).';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Use any of these charakters: a-z, A-Z, 0-9, . (dot) or _ (underscore).';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section671e3224991c71e262b9a287b205ee0c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.reg_username';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.reg_username';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB6c36a861f6511e24b4ded69b5032368(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Your username includes invalid characters.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Your username includes invalid characters.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEbeb0b6a962981d69ca9895237780d97(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'User name already exists. Did you <a href="?" target="_blank">forgot password</a>?';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'User name already exists. Did you <a href="?" target="_blank">forgot password</a>?';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8d7daa263474d019ca6184adeea76f68(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Request failed. Please try again later.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Request failed. Please try again later.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section16e216dda66c750c4dbf625d910e823d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Company profile';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Company profile';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBbaa6bd8dbd39fa10eeba569c807ef3b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Company name';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Company name';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section58a678fea29a5602d3f0a9b11f92d37c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.company';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.company';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section27e39a65acd510be6bfe482e046de86a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Org ID';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Org ID';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1259e38ef89d7617f51ae4e7cd724adc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.ico';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.ico';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section76f6f6628e1c04e10901fef88cb6432f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Tax ID';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Tax ID';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section50bffdf828bd2a464f7a8ed88515104f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.dic';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.dic';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD4c00170a8a9be53393e332e72191fe7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'VAT';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'VAT';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5c10be7e79333fdbc2e46daee2575817(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.zak_icdph';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.zak_icdph';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7e1c22bb4b9b693009c1144090cea093(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Contact';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Contact';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section088c140535585791f45b1310bd27da83(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'First name';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'First name';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB9cd9b3eed761610990f38e661af8efe(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.firstname';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.firstname';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section078ff4c628a5832c7d399c1c0dbad837(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Last name';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Last name';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section00ececc79c1fad4fe072f321904f6f17(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.lastname';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.lastname';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9168bc0e583d2226592437dea05dd9ed(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'E-mail address';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'E-mail address';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1e728b5535b030f6e2ae47754eac0fac(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.email';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.email';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9221efbafae68b73fe2f4fccdacfb988(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Your e-mail address includes invalid characters.';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Your e-mail address includes invalid characters.';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB435ef1b474db733785ab0d9f1089af6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'E-mail already exists. Did you <a href="?" target="_blank">forgot password</a>?';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'E-mail already exists. Did you <a href="?" target="_blank">forgot password</a>?';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section618540ae484f1912a938da7f28cc7466(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Address';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Address';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section53f5102e08e798019ac5510d9591df1c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Street';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Street';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9c689cf6a11a05644403fd8cc4ad12d1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.street';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.street';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section6324e1945458733beb51476bf7b15e88(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.street_no';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.street_no';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB80241b86a8ac26c3fc95229f1f05754(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'City';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'City';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section235133ceab8cca9e745602b30de780b6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.city';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.city';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section356635d831930af31155ac35a262b6c3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.zip';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.zip';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section46a88b3cb0fa88bb97fd54c634a3fe45(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Country';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Country';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section129b73b9aeb65e341be7e00ebefae466(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Or write other<!--country-->:';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Or write other<!--country-->:';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDfe9631083bdead246adfce8ba1126d1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'placeholder.newUser.country';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'placeholder.newUser.country';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1a2e27af446230a7f1d40012756a32c0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Form is not filled correctly';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Form is not filled correctly';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section96b954b4a152d0cff3aa1178ea13712f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Create a new account';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Create a new account';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
