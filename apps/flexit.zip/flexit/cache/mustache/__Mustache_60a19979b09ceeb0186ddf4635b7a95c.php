<?php

class __Mustache_60a19979b09ceeb0186ddf4635b7a95c extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<section class="support-contacts">
';
        $buffer .= $indent . '    <h2 class="headline">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section5066341f040df4fb1a28ce255e7360e4($context, $indent, $value);
        $buffer .= '</h2>
';
        $buffer .= $indent . '    <ul>
';
        $buffer .= $indent . '        <li><a class="email" href="mailto:';
        $value = $this->resolveValue($context->findDot('website.support.email'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">';
        $value = $this->resolveValue($context->findDot('website.support.email'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</a></li>
';
        $buffer .= $indent . '        <li>';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section9e8faf606133c58ceb75ab753d118523($context, $indent, $value);
        $buffer .= ' <a class="phone" href="tel:';
        $value = $this->resolveValue($context->findDot('website.support.phone'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">';
        $value = $this->resolveValue($context->findDot('website.support.phone'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</a>.</li>
';
        $buffer .= $indent . '    </ul>
';
        $buffer .= $indent . '</section>
';
        $buffer .= $indent . '<link concatenate href="http://www.flexit.sk.dev/templates/sections/support-contacts/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section5066341f040df4fb1a28ce255e7360e4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'If you need support reach out for us at';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'If you need support reach out for us at';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9e8faf606133c58ceb75ab753d118523(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '<!--something-->or<!--something else-->';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<!--something-->or<!--something else-->';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
