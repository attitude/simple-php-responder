<?php

class __Mustache_e5ddd0fb32dd30d7ea9da8c8505bc608 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $newContext = array();

        $buffer .= $indent . '<a class="shopping-cart" ng-click="ui.shopVisible = !ui.shopVisible" ng-class="{\'active\': flexit.countProductsInCart() > 0 || ui.shopVisible,\'animated shake\': appState==\'cart-empty\', \'animated bounce\': appState==\'new-in-cart\'}">
';
        $buffer .= $indent . '    <i class="icon icon-cart"></i> <span class="label">';
        // '__' section
        $value = $context->find('__');
        $buffer .= $this->section693e68372657f4100706be2d10a11aa2($context, $indent, $value);
        $buffer .= '</span>
';
        $buffer .= $indent . '    <span ng-if="flexit.countTotalPrice() > 0" class="shopping-car-total-info" ng-cloak class="ng-cloak">[[flexit.countTotalPrice() | currency: "EUR"]]</total>
';
        $buffer .= $indent . '</a>
';
        $buffer .= $indent . '<link concatenate href="http://www/templates/elements/cartbutton/styles.css" media="all" rel="stylesheet" type="text/css" />
';

        return $buffer;
    }

    private function section693e68372657f4100706be2d10a11aa2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = 'Cart';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'Cart';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
